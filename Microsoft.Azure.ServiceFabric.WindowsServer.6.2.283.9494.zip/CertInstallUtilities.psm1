﻿$ServerCertificateName = "CN=ServiceFabricServerCert"
$ClientCertificateName = "CN=ServiceFabricClientCert"

function IsSecurityX509([string]$ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $properties = $jsonConfig.properties
    if ($properties -ne $Null)
    {
        $security = $properties.security
        if ($security -ne $Null )
        {
            $clusterCredentialType = $security.ClusterCredentialType
            return ($clusterCredentialType -ne $Null -And $clusterCredentialType -eq "X509")
        }
    }
    return $False
}

function IsLocalMachine([string] $MachineName)
{
    return ($MachineName -eq $env:ComputerName) -Or ($MachineName -eq "localhost")
}

function GetHostName([string] $iPAddress)
{
    $hostName = $iPAddress
    if ([bool]($iPAddress -as [ipaddress]))
    {
        $hostName = [System.Net.Dns]::GetHostByAddress($iPAddress).HostName
    }

    return $hostName
}

function IsThisMachineServer([string] $ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes

    Foreach ($node in $nodes)
    {
        $hostName = GetHostName -iPAddress $node.iPAddress

        if (IsLocalMachine -MachineName $hostName)
        {
            return $True;
        }
    }

    return $False
}

function InstallCertToLocal([string] $CertSetupScript)
{
    invoke-expression "& '$CertSetupScript' -Install -CertSubjectName '$ServerCertificateName'"
    invoke-expression "& '$CertSetupScript' -Install -CertSubjectName '$ClientCertificateName'"

    $cerLoc = "cert:\LocalMachine\My"
    $cert =  Get-ChildItem -Path $cerLoc | where { $_.Subject -like "*$ServerCertificateName*" }
    $serverthumbprint = $cert.Thumbprint

    $cert =  Get-ChildItem -Path $cerLoc | where { $_.Subject -like "*$ClientCertificateName*" }
    $clientthumbprint = $cert.Thumbprint
    
    return $serverthumbprint,$clientthumbprint
}

function IsOneBox([string] $ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes

    $machineNames = $nodes.iPAddress | select -uniq
    return ($machineNames.Count -eq 1)
}

function ExportCertificateToLocal([string]$PackageRoot, [string]$CertSetupScript, [string]$ServerThumbprint, [string]$ClientThumbprint, [string]$ClusterConfigFilePath)
{
    $serverCertificate = ExportCertificate -PackageRoot $packageRoot -Thumbprint $serverThumbprint -Name "server"
    $clientCertificate = ExportCertificate -PackageRoot $packageRoot -Thumbprint $clientThumbprint -Name "client"

    Write-Host "Server certificate is exported to $($serverCertificate[0]) with the password $($serverCertificate[1])"
    Write-Host "Client certificate is exported to $($clientCertificate[0]) with the password $($clientCertificate[1])"

    # If the current machine is server, then remove the client cert. If the current machine is client, then remove server cert.
    if (IsThisMachineServer -ClusterConfigFilePath $ClusterConfigFilePath)
    {
        if (-Not (IsOneBox -ClusterConfigFilePath $ClusterConfigFilePath))
        {
            Write-Host "Remove client certificate on localhost."
            invoke-expression "& '$CertSetupScript' -Clean -CertSubjectName '$ClientCertificateName'"
        }
    }
    else 
    {
        Write-Host "Remove server certificate on localhost."
        invoke-expression "& '$CertSetupScript' -Clean -CertSubjectName '$ServerCertificateName'"
    }

    return $serverCertificate
}

function ExportCertificate([string]$PackageRoot, [string]$Thumbprint, [string] $Name)
{
    $OutputCertificateFolder = Join-Path $PackageRoot "Certificates"
    if (-Not(Test-Path $OutputCertificateFolder))
    {
        New-Item -ItemType Directory -Force -Path $OutputCertificateFolder > $null
    }

    $PfxFilePath = "$OutputCertificateFolder\$Name.pfx"
    $randomnum = Get-Random
    $pswd = ConvertTo-SecureString -String "$randomnum" -Force -AsPlainText
    
    Get-ChildItem -Path "cert:\localMachine\my\$Thumbprint" | Export-PfxCertificate -FilePath $PfxFilePath -Password $pswd > $null

    return $PfxFilePath,$randomnum
}

function ModifyJsonThumbprint([string]$ClusterConfigFilePath, [string]$ServerThumbprint, [string]$ClientThumbprint, [string]$OutputPath)
{
    Write-Host "Modify thumbprint in $ClusterConfigFilePath"

    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $securityCertInfo = New-Object -TypeName PSObject

    $certificate= New-Object –TypeName PSObject
    $certificate | Add-Member -Name "Thumbprint" -value "$ServerThumbprint" -MemberType NoteProperty
    $certificate | Add-Member -Name "X509StoreName" -value "My" -MemberType NoteProperty

    $clientcertificate = New-Object -TypeName PSObject
    $clientcertificate | Add-Member -Name "CertificateThumbprint" -value "$ClientThumbprint" -MemberType NoteProperty
    $clientcertificate | Add-Member -Name "IsAdmin" -value $true -MemberType NoteProperty
    $clientcertificateArray = @()
    $clientcertificateArray += $clientcertificate

    $securityCertInfo | Add-Member -Name "ClusterCertificate" -value $certificate -MemberType NoteProperty
    $securityCertInfo | Add-Member -Name "ServerCertificate" -value $certificate -MemberType NoteProperty
    $securityCertInfo | Add-Member -Name "ClientCertificateThumbprints" -value $clientcertificateArray -MemberType NoteProperty

    if (IsReverseProxyEndPointConfigured -ClusterConfigFilePath $ClusterConfigFilePath)
    {
        $securityCertInfo | Add-Member -Name "ReverseProxyCertificate" -value $certificate -MemberType NoteProperty
    }

    $jsonConfig.properties.security.CertificateInformation = $securityCertInfo
    $jsonObject = ConvertTo-Json $jsonConfig -Depth 10
    $jsonObject > $OutputPath
}

function IsReverseProxyEndPointConfigured([string]$ClusterConfigFilePath)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes
    $properties = $jsonConfig.properties
    $nodetypes = $properties.nodetypes

    foreach($node in $nodes)
    {
        $nodetypeRef = $node.nodetypeRef
        foreach($nodetype in $nodetypes)
        {
            if ($nodetype.Name -eq $nodetypeRef)
            {
                if ($nodetype.reverseProxyEndpointPort -ne $Null)
                {
                    return $True;
                }
            }
        }
    }

    return $False
}

function AddToTrustedHosts([string]$MachineName)
{
    Write-Host "Adding $MachineName to TrustedHosts"
    Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$MachineName" -Concatenate -Force
}

function InstallCertToRemote([string]$ClusterConfigFilePath, [string]$CertificatePath, [string]$Password)
{
    $jsonConfig = Get-Content $ClusterConfigFilePath -Raw | ConvertFrom-Json
    $nodes = $jsonConfig.nodes
    $pswd = ConvertTo-SecureString -String $Password -Force -AsPlainText
    $certBytes = [System.IO.File]::ReadAllBytes($CertificatePath)

    $iPAddressList = $nodes.iPAddress | select -uniq

    Foreach ($iPAddress in $iPAddressList)
    {
        $machineName = GetHostName -iPAddress $iPAddress

        if (IsLocalMachine -MachineName $machineName)
        {
            Write-Host "Skipping certificate installation in $machineName."
            continue
        }

        AddToTrustedHosts -MachineName $machineName

        Write-Host "Connectting to $machineName"

        for($retry = 0; $retry -le 2; $retry ++)
        {
            Write-Host "Installing server certificate in $machineName for iteration $retry"
            Invoke-Command -ComputerName $machineName -ScriptBlock {
                param($pswd, $certBytes)
                Get-ChildItem -Path Cert:\LocalMachine\My | ? { $_.Subject -like "*$ServerCertificateName*" } | Remove-Item -Force
                Get-ChildItem -Path Cert:\LocalMachine\root | ? { $_.Subject -like "*$ServerCertificateName*" } | Remove-Item -Force
                Get-ChildItem -Path Cert:\CurrentUser\My | ? { $_.Subject -like "*$ServerCertificateName*" } | Remove-Item -Force

                $certPath = [System.IO.Path]::GetTempFileName()
                [system.IO.file]::WriteAllBytes($certPath, $certBytes);

                Import-PfxCertificate -Exportable -CertStoreLocation Cert:\LocalMachine\My -FilePath $certPath -Password $pswd > $null   
                Import-PfxCertificate -Exportable -CertStoreLocation Cert:\LocalMachine\root -FilePath $certPath -Password $pswd > $null  
                Import-PfxCertificate -Exportable -CertStoreLocation Cert:\CurrentUser\My -FilePath $certPath -Password $pswd > $null  

            } -ArgumentList $pswd,$certBytes

            if ($?)
            {
                Write-Host "Installed server certificate in $machineName"
                break
            }

            if ($retry -eq 2)
            {
                Write-Host "Installing server certificate in $machineName failed after 3 attemps"
            }
            else 
            {
                Write-Host "Unable to intall server certificate in $machineName, retry after 30 seconds..."
                Start-Sleep -Seconds 30
            } 
        }        
    }  
}
# SIG # Begin signature block
# MIIdkQYJKoZIhvcNAQcCoIIdgjCCHX4CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUA9N5lOI398Qw7sSN8QBflzhp
# H/mgghhVMIIEwzCCA6ugAwIBAgITMwAAALfuAa/68MeouwAAAAAAtzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODQ1
# WhcNMTgwOTA3MTc1ODQ1WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkJCRUMtMzBDQS0yREJFMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuCMjQSw3ep1m
# SndFRK0xgVRgm9wSl3i2llRtDdxzAWN9gQtYAE3hJP0/pV/7HHkshYPfMIRf7Pm/
# dxSsAN+7ATnNUk+wpe46rfe0FDNxoE6CYaiMSNjKcMXH55bGXNnwrrcsMaZrVXzS
# IQcmAhUQw1jdLntbdTyCAwJ2UqF/XmVtWV/U466G8JP8VGLddeaucY0YKhgYwMnt
# Sp9ElCkVDcUP01L9pgn9JmKUfD3yFt2p1iZ9VKCrlla10JQwe7aNW7xjzXxvcvlV
# IXeA4QSabo4dq8HUh7JoYMqh3ufr2yNgTs/rSxG6D5ITcI0PZkH4PYjO2GbGIcOF
# RVOf5RxVrwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFJZnqouaH5kw+n1zGHTDXjCT
# 5OMAMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAG7J+Fdd7DgxG6awnA8opmQfW5DHnNDC/JPLof1sA8Nqczym
# cnWIHmlWhqA7TUy4q02lKenO+R/vbmHna1BrC/KkczAyhOzkI2WFU3PeYubv8EjK
# fYPmrNvS8fCsHJXj3N6fuFwXkHmCVBjTchK93auG09ckBYx5Mt4zW0TUbbw4/QAZ
# X64rbut6Aw/C1bpxqBb8vvMssBB9Hw2m8ApFTApaEVOE/sKemVlq0VIo0fCXqRST
# Lb6/QOav3S8S+N34RBNx/aKKOFzBDy6Ni45QvtRfBoNX3f4/mm4TFdNs+SeLQA+0
# oBs7UgdoxGSpX6vsWaH8dtlBw3NZK7SFi9bBMI4wggYBMIID6aADAgECAhMzAAAA
# xOmJ+HqBUOn/AAAAAADEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTEwHhcNMTcwODExMjAyMDI0WhcNMTgwODExMjAyMDI0WjB0
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK
# AoIBAQCIirgkwwePmoB5FfwmYPxyiCz69KOXiJZGt6PLX4kvOjMuHpF4+nypH4IB
# tXrLGrwDykbrxZn3+wQd8oUK/yJuofJnPcUnGOUoH/UElEFj7OO6FYztE5o13jhw
# VG877K1FCTBJwb6PMJkMy3bJ93OVFnfRi7uUxwiFIO0eqDXxccLgdABLitLckevW
# eP6N+q1giD29uR+uYpe/xYSxkK7WryvTVPs12s1xkuYe/+xxa8t/CHZ04BBRSNTx
# AMhITKMHNeVZDf18nMjmWuOF9daaDx+OpuSEF8HWyp8dAcf9SKcTkjOXIUgy+MIk
# ogCyvlPKg24pW4HvOG6A87vsEwvrAgMBAAGjggGAMIIBfDAfBgNVHSUEGDAWBgor
# BgEEAYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUy9ZihM9gOer/Z8Jc0si7q7fD
# E5gwUgYDVR0RBEswSaRHMEUxDTALBgNVBAsTBE1PUFIxNDAyBgNVBAUTKzIzMDAx
# MitjODA0YjVlYS00OWI0LTQyMzgtODM2Mi1kODUxZmEyMjU0ZmMwHwYDVR0jBBgw
# FoAUSG5k5VAF04KqFzc3IrVtqMp1ApUwVAYDVR0fBE0wSzBJoEegRYZDaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljQ29kU2lnUENBMjAxMV8y
# MDExLTA3LTA4LmNybDBhBggrBgEFBQcBAQRVMFMwUQYIKwYBBQUHMAKGRWh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljQ29kU2lnUENBMjAx
# MV8yMDExLTA3LTA4LmNydDAMBgNVHRMBAf8EAjAAMA0GCSqGSIb3DQEBCwUAA4IC
# AQAGFh/bV8JQyCNPolF41+34/c291cDx+RtW7VPIaUcF1cTL7OL8mVuVXxE4KMAF
# RRPgmnmIvGar27vrAlUjtz0jeEFtrvjxAFqUmYoczAmV0JocRDCppRbHukdb9Ss0
# i5+PWDfDThyvIsoQzdiCEKk18K4iyI8kpoGL3ycc5GYdiT4u/1cDTcFug6Ay67Sz
# L1BWXQaxFYzIHWO3cwzj1nomDyqWRacygz6WPldJdyOJ/rEQx4rlCBVRxStaMVs5
# apaopIhrlihv8cSu6r1FF8xiToG1VBpHjpilbcBuJ8b4Jx/I7SCpC7HxzgualOJq
# nWmDoTbXbSD+hdX/w7iXNgn+PRTBmBSpwIbM74LBq1UkQxi1SIV4htD50p0/GdkU
# ieeNn2gkiGg7qceATibnCCFMY/2ckxVNM7VWYE/XSrk4jv8u3bFfpENryXjPsbtr
# j4Nsh3Kq6qX7n90a1jn8ZMltPgjlfIOxrbyjunvPllakeljLEkdi0iHv/DzEMQv3
# Lz5kpTdvYFA/t0SQT6ALi75+WPbHZ4dh256YxMiMy29H4cAulO2x9rAwbexqSajp
# lnbIvQjE/jv1rnM3BrJWzxnUu/WUyocc8oBqAU+2G4Fzs9NbIj86WBjfiO5nxEmn
# L9wliz1e0Ow0RJEdvJEMdoI+78TYLaEEAo5I+e/dAs8DojCCBgcwggPvoAMCAQIC
# CmEWaDQAAAAAABwwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmSJomT8ixkARkWA2Nv
# bTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTA3MDQwMzEyNTMwOVoXDTIx
# MDQwMzEzMDMwOVowdzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEhMB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAn6Fssd/bSJIqfGsuGeG94uPFmVEjUK3O3RhO
# JA/u0afRTK10MCAR6wfVVJUVSZQbQpKumFwwJtoAa+h7veyJBw/3DgSY8InMH8sz
# JIed8vRnHCz8e+eIHernTqOhwSNTyo36Rc8J0F6v0LBCBKL5pmyTZ9co3EZTsIbQ
# 5ShGLieshk9VUgzkAyz7apCQMG6H81kwnfp+1pez6CGXfvjSE/MIt1NtUrRFkJ9I
# AEpHZhEnKWaol+TTBoFKovmEpxFHFAmCn4TtVXj+AZodUAiFABAwRu233iNGu8Qt
# VJ+vHnhBMXfMm987g5OhYQK1HQ2x/PebsgHOIktU//kFw8IgCwIDAQABo4IBqzCC
# AacwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUIzT42VJGcArtQPt2+7MrsMM1
# sw8wCwYDVR0PBAQDAgGGMBAGCSsGAQQBgjcVAQQDAgEAMIGYBgNVHSMEgZAwgY2A
# FA6sgmBAVieX5SUT/CrhClOVWeSkoWOkYTBfMRMwEQYKCZImiZPyLGQBGRYDY29t
# MRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQg
# Um9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHmCEHmtFqFKoKWtTHNY9AcTLmUwUAYD
# VR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwv
# cHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEBBEgwRjBE
# BggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9N
# aWNyb3NvZnRSb290Q2VydC5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggIBABCXisNcA0Q23em0rXfbznlRTQGxLnRxW20ME6vOvnuPuC7U
# EqKMbWK4VwLLTiATUJndekDiV7uvWJoc4R0Bhqy7ePKL0Ow7Ae7ivo8KBciNSOLw
# UxXdT6uS5OeNatWAweaU8gYvhQPpkSokInD79vzkeJkuDfcH4nC8GE6djmsKcpW4
# oTmcZy3FUQ7qYlw/FpiLID/iBxoy+cwxSnYxPStyC8jqcD3/hQoT38IKYY7w17gX
# 606Lf8U1K16jv+u8fQtCe9RTciHuMMq7eGVcWwEXChQO0toUmPU8uWZYsy0v5/mF
# hsxRVuidcJRsrDlM1PZ5v6oYemIp76KbKTQGdxpiyT0ebR+C8AvHLLvPQ7Pl+ex9
# teOkqHQ1uE7FcSMSJnYLPFKMcVpGQxS8s7OwTWfIn0L/gHkhgJ4VMGboQhJeGsie
# IiHQQ+kr6bv0SMws1NgygEwmKkgkX1rqVu+m3pmdyjpvvYEndAYR7nYhv5uCwSdU
# trFqPYmhdmG0bqETpr+qR/ASb/2KMmyy/t9RyIwjyWa9nR2HEmQCPS2vWY+45CHl
# tbDKY7R4VAXUQS5QrJSwpXirs6CWdRrZkocTdSIvMqgIbqBbjCW/oO+EyiHW6x5P
# yZruSeD3AWVviQt9yGnI5m7qp5fOMSn/DsVbXNhNG6HY+i+ePy5VFmvJE6P9MIIH
# ejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0
# IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5
# WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDEx
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00
# uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kN
# eWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/n
# qwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3V
# XHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6x
# jF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5k
# f1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4c
# I6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bys
# AoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexN
# STCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93
# KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX
# 3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEA
# MB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4K
# AFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSME
# GDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRw
# Oi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJB
# dXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcw
# AoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJB
# dXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcu
# AzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9w
# cy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEA
# bABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3
# DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74
# w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQ
# sP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6Sp
# BQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd
# 8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJx
# Jxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9
# Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEG
# sXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AA
# KcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/
# 1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EK
# sT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCBKYw
# ggSiAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# KDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAADE
# 6Yn4eoFQ6f8AAAAAAMQwCQYFKw4DAhoFAKCBujAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0B
# CQQxFgQUHmDOtwTb37QTnNDRAII3I796s68wWgYKKwYBBAGCNwIBDDFMMEqgJIAi
# AE0AaQBjAHIAbwBzAG8AZgB0ACAAVwBpAG4AZABvAHcAc6EigCBodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vd2luZG93czANBgkqhkiG9w0BAQEFAASCAQCH1X9V77uB
# PJzXbdrgr4Dg2+Kz3ZE549b/mwJ9nX5d8VR77WFr70G2s1b/8haDffy2l+fCJ3zq
# KlMvulmsz2ZqDyf4sDl7Bn07Gq5Vk3BB3+zE4FVvuL8lk4uGJkgTpiwgqyErXOvK
# ZWHWyxsINgH3okB44QBzmKrqKcXF6un9zZC1dq8Elqxx7DQZ2NZ6BxBzhucDhaMn
# B9Vky9i8BIUBRjUCWFAuYEQkfJIIMbbj0szJ+3WEYj/yjrVkfAgTHnsfiuzQmi6e
# 9IwTiikBF1gWIaQCianV0TaV9zXEgX6YX3ek/SPJYg8t8KzRfO72dy1eEjQpYHA7
# SBGt/V/PFQpToYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQQITMwAAALfuAa/68MeouwAAAAAAtzAJBgUrDgMC
# GgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcN
# MTgwNTE4MTAyMDI4WjAjBgkqhkiG9w0BCQQxFgQUV2fWWtTFhP8utLAu8aCzKuqY
# Y6gwDQYJKoZIhvcNAQEFBQAEggEAp3qjIqEPya9SglNWW2CG8jcWTY/djmU6AEhV
# j9K2ISJn2s2iwRklvfRlGMWE9hyYdH4V9bGsxppwffecVjGObCVBWb1nOgmhA6lO
# UWeyjX2XWoWbd6FkbkxKe1q57qKqGnqwfqWTwWvUJxxJwzAZIQ2QMa8svtj0WqKR
# OGqd4JqrKrZf2tcGBIoETy6qvr0tthXeJYJu05w4shVDeA5nZarlG0Q60EAjrx8v
# WrGXdXnIq8JESAIU/PxeKqXAxZNkgexqigAzRtnFfl0uBVKJU08K5uT/H/qeps+q
# 6q81rE7gqGaJp9ZTyPsfv9bo7aOQjSh7IPHSY7z0US62avZGoA==
# SIG # End signature block
