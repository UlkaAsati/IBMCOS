﻿ /***** DateTime functions *****/
function functionLibrary() {
    var DAY = function DAY(date) {
        if (date == null)
            return -1;
        return new Date(date).getDate();
    }
    var ADDDAYS = function ADDDAYS(date, days) {
        if (days == null || isNaN(days) || days < 0)
            return date;
        var dat = new Date(date);
        dat.setDate(dat.getDate() + days);
        return dat;
    }
    //date time months in javascript start at 0
    var ADDMONTHS = function ADDMONTHS(date, months) {
        if (date == null || isNaN(months) || months < 0)
            return date;
        if (date && months) {
            var m, d = (date = new Date(+date)).getUTCDate()

            date.setUTCMonth(date.getUTCMonth() + months, 1)
            m = date.getUTCMonth()
            date.setUTCDate(d)
            if (date.getUTCMonth() !== m) date.setUTCDate(0)
        }
        return date;
    }
    var ADDYEARS = function ADDYEARS(date, years) {
        if (date == null || isNaN(years) || years < 0)
            return date;
        var dat = new Date(date);
        dat.setFullYear(dat.getFullYear() + years);
        return dat;
    }
    var MONTH = function MONTH(date) {
        if (date == null)
            return -1;
        return new Date(date).getMonth()
    }
    var YEAR = function YEAR(date) {
        if (date == null)
            return -1;
        return new Date(date).getFullYear()
    }
    var DATE = function DATE(year, month, day) {
        var yearValid = 1;
        var monthValiid = 1;
        var dayValid = 1;
        if (year != null && !isNaN(year)) {
            yearValid = year;
        }
        if (month != null && !isNaN(month) && month >= 0 && month <= 12) {
            monthValiid = month;
        }
        if (day != null && !isNaN(day) && day > 0 && day < 32) {
            dayValid = day;
        }
        return new Date(yearValid, monthValid, dayValid);
    }
    var DATETIMEVALUE = function DATETIMEVALUE(date) {
        if (date == null)
            return new Date();
        var timestamp = Date.parse(date);
        if (isNaN(timestamp) == false) {
            dat = new Date(timestamp);
        }
    }
    var DATEVALUE = function DATEVALUE(date) {
        var dat = Date.now();
        if (date == null)
            return dat;
        var timestamp = Date.parse(date);
        if (isNaN(timestamp) == false) {
            dat = new Date(timestamp);
        }
        return dat;
    }
    var DATEDIFF = function DATEDIFF(interval, date1, date2) {
        if (date1 == null || date2 == null)
            return -1;
        var t1 = Date.parse(date1);
        var t2 = Date.parse(date2);
        var d1 = new Date(t1);
        var d2 = new Date(t2);
        var ts = t2 - t1;
        if (isNaN(t1) || isNaN(t2)) {
            return -1;
        }
        switch (interval) {
            case "Year":
                return d2.getFullYear() - d1.getFullYear();
            case "Month":
                return d2.getMonth - d2.getMonth + (12 * d2.getFullYear() - d1.getFullYear());
            case "Second":
                return ts / 1000;
            case "Minute":
                return ts / 1000 / 60;
            case "Hour":
                return ts * 1000 * 60 / 60;
            case "Day":
                return ts / 1000 / 60 / 60 / 24; 
            case "Weekday":
                return ts / 1000 / 60 / 60 / 24 / 7;
            default:
                return ts / 1000;
        }
    }
    var DATECOMPARE = function DATECOMPARE(date1, date2) {
        if (date1 == null || date2 == null)
            return -1;
        var t1 = Date.parse(date1);
        var t2 = Date.parse(date2);
        if (t2 > t1)
            return 1;
        else if (t2 < t1)
            return -1;
        else
            return 0;
    }
    var FORMATDATE = function FORMATDATE(date, format) {
        if (date == null)
            return new Date(10,10,10);
        if (format == null)
            return date;
        var d = new Date(Date.parse(date));        
        var formattedDate = format;

        var month = d.getMonth() + 1;        
        var day = d.getDate();
        var hour = d.getHours();
        var minute = d.getMinutes();
        var second = d.getSeconds();
        var doubleMonth = month;
        var doubleDay = day;
        var doubleHour = hour;
        var doubleMinute = minute;
        var doubleSecond = second;
        if (month < 10)
            doubleMonth = "0" + month;        
        if (day < 10)
            doubleDay = "0" + day;        
        if (hour < 10)
            doubleHour = "0" + hour;
        if (minute < 10)
            doubleMinute = "0" + minute;
        if (second < 10)
            doubleSecond = "0" + second;
        formattedDate = formattedDate.split("yyyy").join(d.getFullYear());
        formattedDate = formattedDate.split("yyy").join(d.getFullYear());
        formattedDate = formattedDate.split("yy").join(d.getFullYear().toString().substring(-2));
        formattedDate = formattedDate.split("y").join(d.getFullYear().toString().substring(-2));
        formattedDate = formattedDate.split("MM").join(doubleMonth);
        formattedDate = formattedDate.split("M").join(month);
        formattedDate = formattedDate.split("dd").join(doubleDay);
        formattedDate = formattedDate.split("d").join(day);
        formattedDate = formattedDate.split("HH").join(doubleHour);
        formattedDate = formattedDate.split("H").join(hour);
        formattedDate = formattedDate.split("mm").join(doubleMinute);
        formattedDate = formattedDate.split("m").join(minute);
        formattedDate = formattedDate.split("ss").join(doubleSecond);
        formattedDate = formattedDate.split("s").join(second);
        return formattedDate;
     }
    
    var NOW = function NOW() {
        return Date.now();
    }
    var TODAYUTC = function TODAYUTC() {
        return new Date().getTime();
    }
    var TODAY = function TODAY() {
        return new Date();
    }
    /******** string functions ******/
    var CONCAT = function CONCAT() {
        var retString = "";
        for (var i = 0; i < arguments.length; i++) {
            retString = retString + arguments[i];
        }
        return retString;
    }
    var BEGINS = function BEGINS(str, strToMatch) {
        if (str == null || strToMatch == null)
            return false;
        return str.startsWith(strToMatch);
    }
    var CONTAINS = function CONTAINS(str, strContained) {
        if (str == null || strContained == null)
            return false;
        return str.includes(strContained);
    }
    var FIND = function FIND(str, strToFind) {
        if (str == null || strToFind == null)
            return false;
        return str.indexOf(strToFind);
    }
    var REGEX = function REGEX(str, pattern) {
        if (str == null || pattern == null)
            return false;

        var matches = str.match(new RegExp(pattern));
        if (matches)
            return true;
        return false;
    }
    var LEFT = function LEFT(str, numberOfChar) {
        if (str == null || numberOfChar == null || isNaN(numberOfChar))
            return "";
        return str.substring(0, numberOfChar);
    }
    var LEN = function LEN(str) {
        if (str == null)
            return -1;
        return str.length;
    }
    var LOWER = function LOWER(str) {
        if (str == null)
            return "";
        return str.toLocaleLowerCase();
    }
    var UPPER = function UPPER(str) {
        if (str == null)
            return "";
        return str.toUpperCase();
    }
    var LPAD = function LPAD(str, paddingAmount, charToPad) {
        if (str == null || paddingAmount == null || charToPad == null)
            return "";
        //var strTemp = JSON.stringify(str);
        return Array(Number(paddingAmount) + 1).join(charToPad) + str;
    }
    var RPAD = function RPAD(str, paddingAmount, charToPad) {
        if (str == null || paddingAmount == null || charToPad == null)
            return "";
        return str + Array.join(Number(paddingAmount) + 1).join(charToPad);
    }
    var MID = function MID(str, startnum, numberOfChar) {
        if (str == null || startnum == null || numberOfChar == null) {
            return "";
        }
        return str.substring(startnum, retStr.length - startnum - numberOfChar)
    }
    var RIGHT = function RIGHT(str, numberOfChar) {
        if (str == null || numberOfChar == null)
            return "";
        return str.substring(str.length - numberOfChar, str.length);
    }
    var SUBSTITUTE = function SUBSTITUTE(str, oldText, newText) {
        if (str == null)
            return "";
        if (oldText == null || newText == null)
            return str;
        return str.split(oldText).join(newText);
    }
    var TEXT = function TEXT(str) {
        return JSON.stringify(str);
    }
    var TRIM = function TRIM(str) {
        if (str == null)
            return "";
        return str.trim();
    }
    /***** object comparisons ****/
    var BLANKVALUE = function BLANKVALUE(obj1, obj2) {
        if (obj1 == null || (obj1 == "")) {
            return obj2;
        }
        return obj1;
    }
    var ISBLANK = function ISBLANK(obj) {
        if (obj == "")
            return true;
        return false;
    }
    var ISNULL = function ISNULL(obj) {
        if (obj == null)
            return true;
    }
    var NULLVALUE = function NULLVALUE(value, substitueValue) {
        if (value === null) {
            return substitueValue;
        }
        return value;
    }
    /******* LOGICAL ********/
    var AND = function AND() {
        for (var i = 0; i < arguments.length; i++) {
            if (arguments[i] == null || arguments[i] == false)
                return false;
        }
        return true;
    }
    var OR = function OR() {
        for (var i = 0; i < arguments.length; i++) {
            if (arguments[i] == null)
                return false;
            else if (arguments[i] == true)
                return true;
        }
        return true;
    }
    var NOT = function NOT(b) {
        if (b == null)
            return false;
        return !b;
    }
    var CASE = function CASE(option) {
        var defaultCase = false;
        var iterationCount = arguments.length;
        if ((arguments.length + 1) % 2 != 0) {
            defaultCase = true;
            iterationCount--;
        }
        for (var i = 1; i < iterationCount; i++) {
            if (option == arguments[i])
                return arguments[i + 1];
            else
                i++;
        }
        if (defaultCase)
            return arguments[arguments.length - 1];
        throw "No matching cases for '" + option + "'.";
    }
    var IF = function IF(logicalTest, valueIfTrue, valueIfFalse) {
        if (logicalTest == null)
            return valueIfFalse;
        if (logicalTest)
            return valueIfTrue;
        else
            return valueIfFalse;
    }
    /***** MATH AND NUMBERS *****/
    var ISNUMBER = function ISNUMBER(num) {
        if (isNaN(num))
            return false;
        return true;
    }
    var ABS = function ABS(num) {
        if (num == null || isNaN(num))
            return -1;
        return Math.abs(num);
    }
    var MOD = function MOD(num1, num2) {
        if (num1 == null || num2 == null || isNaN(num1) || isNaN(num2))
            return -1;
        return num1 % num2;
    }
    var ROUND = function ROUND(num, digits) {
        if (num == null || digits == null || isNaN(num) || isNaN(digits))
            return -1;
        var factor = Math.pow(10, digits);
        return Math.round(num * factor) / factor;
    }
    var SQRT = function SQRT(num) {
        if (num == null || isNaN(num)) {
            return - 1;
        }
        return Math.sqrt(num);
    }
    var EXP = function EXP(num) {
        if (num == null || isNaN(num))
            return -1;
        return Math.exp(num);
    }
    var LN = function LN(num) {
        if (num == null || isNaN(num))
            return -1;
        return Math.log(num);
    }
    var LOG10 = function LOG10(num) {
        if (num == null || isNaN(num))
            return - 1;
        return Math.log10(num);
    }
    var CEILING = function CEILING(num) {
        if (num == null || isNaN(num)) {
            return -1;
        }
        return Math.ceil(num);
    }
    var FLOOR = function FLOOR(num) {
        if (num == null || isNaN(num))
            return - 1;
        return Math.floor(num);
    }
    var MAX = function MAX(num1, num2) {
        if (num2 > num1)
            return num2;
        else
            return num1;
    };
    var MIN = function MAX(num1, num2) {
        if (num2 < num1)
            return num2;
        else
            return num1;
    };
    var VALUE = function VALUE(str) {
        if (str == null)
            return 0;
        return Number(str);
    }
    /***** GEOLOCATION *****/
    var DISTANCE = function DISTANCE(cor1, cor2, unit) {
        var longDist = cor2["longitude"] - cor1["longitude"];
        var latDist = cor2["latitude"] - cor1["latitude"];
        return { "latitude": latDist, "logitude": longDist };
    }
    var GEOLOCATION = function GEOLOCATION(latitude, longitude) {
        return { "latitude": latitude, "longitude": longitude };
    }
    /****** html and js******/
    var HYPERLINK = function HYPERLINK(displayText, link) {
        var display = "";
        var usedLink = "";
        if (displayText != null)
            display = displayText;
        if (link != null)
            usedLink = link;
        var hyperlink = "<a href=\"" + link + "\">" + displayText + "</a>";
        return hyperlink;
    }
    var HTMLENCODE = function HTMLENCODE(str) {
        return $('<div/>').text(str).html();
    }
    var URLENCODE = function URLENCODE(str) {
        return encodeURI(str);
    }
    var JSENCODE = function JSENCODE(str) {
        return escape(str);
    }
    var JSHTMLENCODE = function JSHTMLENCODE(str) {
        if (str == null)
            return "";
        return JSENCODE(HTMLENCODE(str));
    }
    /****** MultiSelect *****/
    var INCLUDES = function INCLUDES(collection, str) {
        if (collection == null || str == null)
            return false;
        var list = collection.split(",");
        return list.includes(str);
    }
    var COLLECTIONTOSTRING = function COLLECTIONTOSTRING(collection) {
        if (collection == null)
            return "";
        return collection;
    }
    var ADDTOCOLLECTION = function ADDTOCOLLECTION(collection, str) {
        if (collection == null) 
            return "";        
        if (str == null)
            return collection;

        return collection += "," + str;
    }
    var DELETEFROMCOLLECTION = function DELETEFROMCOLLECTION(collection, str) {
        if (collection == null)
            return "";
        if (str == null)
            return collection;

        var list = collection.split(",");
        var ind = list.indexOf(str);
        if (ind == -1)
            return collection;
        else {
            list = list.splice(ind, 1);
            return list.toString();
        }
    }
    var CLEARCOLLECTION = function CLEARCOLLECTION(collection) {
        return "";
    } 
    /**** misc ****/
    var CASESAFEID = function CASESAFEID(id) {
        if(id == null)
            return "";
        if (id.length == 18) return id;
        if (id.length != 15) return "Illegal argument length. 15 char string expected.";

        var triplet = [id.substring(0, 5), id.substring(5, 10), id.substring(10, 15)];
        var str = "";
        for (var i = 0; i < 3; i++) {
            str = "";
            var reversed = triplet[i].split("").reverse().join("");
            for (var j = 0; j < reversed.length; j++) {
                if (reversed[j] == reversed[j].toLocaleLowerCase())
                    str += 0;
                else
                    str += 1;
            }
        }
    }
    var BinaryIdLookup =
        {
            "00000": "A",
            "00001": "B",
            "00010": "C",
            "00011": "D",
            "00100": "E",
            "00101": "F",
            "00110": "G",
            "00111": "H",
            "01000": "I",
            "01001": "J",
            "01010": "K",
            "01011": "L",
            "01100": "M",
            "01101": "N",
            "01110": "O",
            "01111": "P",
            "10000": "Q",
            "10001": "R",
            "10010": "S",
            "10011": "T",
            "10100": "U",
            "10101": "V",
            "10110": "W",
            "10111": "X",
            "11000": "Y",
            "11001": "Z",
            "11010": "0",
            "11011": "1",
            "11100": "2",
            "11101": "3",
            "11110": "4",
            "11111": "5",
        }
    var ISCHANGED = function ISCHANGED(field) {
        return false;
    }
    var OLDVALUE = function OLDVALUE(field) {
        return "";
    }
    var CONVERTTOINT = function CONVERTTOINT(obj) {
        return Math.trunc(obj);
    }
    var CONVERTTODOUBLE = function CONVERTTODOUBLE(obj) {
        return Number(obj);
    }
    var CONVERTTODECIMAL = function CONVERTTODECIMAL(obj) {
        return Number(obj);
    }

    return {
        "DAY": DAY,
        "ADDYEARS": ADDYEARS,
        "ADDDAYS": ADDDAYS,
        "ADDMONTHS": ADDMONTHS,
        "MONTH": MONTH,
        "YEAR": YEAR,
        "DATE": DATE,
        "DATEVALUE": DATEVALUE,
        "DATETIMEVALUE": DATETIMEVALUE,
        "DATECOMPARE": DATECOMPARE,
        "DATEDIFF": DATEDIFF,
        "FORMATDATE": FORMATDATE,
        "NOW": NOW,
        "TODAYUTC": TODAYUTC,
        "TODAY": TODAY,
        "CONCAT": CONCAT,
        "BEGINS": BEGINS,
        "CONTAINS": CONTAINS,
        "FIND": FIND,
        "REGEX": REGEX,
        "LEFT": LEFT,
        "MID": MID,
        "RIGHT": RIGHT,
        "LEN": LEN,
        "LOWER": LOWER,
        "UPPER": UPPER,
        "LPAD": LPAD,
        "RPAD": RPAD,
        "SUBSTITUTE": SUBSTITUTE,
        "TEXT": TEXT,
        "TRIM": TRIM,
        "BLANKVALUE": BLANKVALUE,
        "ISBLANK": ISBLANK,
        "ISNULL": ISNULL,
        "NULLVALUE": NULLVALUE,
        "AND": AND,
        "OR": OR,
        "NOT": NOT,
        "CASE": CASE,
        "IF": IF,
        "ISNUMBER": ISNUMBER,
        "ABS": ABS,
        "MOD": MOD,
        "ROUND": ROUND,
        "SQRT": SQRT,
        "EXP": EXP,
        "LN": LN,
        "LOG10": LOG10,
        "CEILING": CEILING,
        "FLOOR": FLOOR,
        "MAX": MAX,
        "MIN": MIN,
        "VALUE": VALUE,
        "DISTANCE": DISTANCE,
        "GEOLOCATION": GEOLOCATION,
        "HYPERLINK": HYPERLINK,
        "HTMLENCODE": HTMLENCODE,
        "URLENCODE": URLENCODE,
        "JSENCODE": JSENCODE,
        "JSHTMLENCODE": JSHTMLENCODE,
        "CASESAFEID": CASESAFEID,
        "ISCHANGED": ISCHANGED,
        "OLDVALUE": OLDVALUE,
        "INCLUDES": INCLUDES,
        "COLLECTIONTOSTRING": COLLECTIONTOSTRING,
        "ADDTOCOLLECTION": ADDTOCOLLECTION,
        "DELETEFROMCOLLECTION": DELETEFROMCOLLECTION,
        "CLEARCOLLECTION": CLEARCOLLECTION,
        "CONVERTTOINT": CONVERTTOINT,
        "CONVERTTODOUBLE": CONVERTTODOUBLE,
        "CONVERTTODECIMAL": CONVERTTODECIMAL,
    }
}
