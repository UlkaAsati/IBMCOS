<#
.SYNOPSIS 
Deploys a Service Fabric application type to a cluster.

.DESCRIPTION
This script deploys a Service Fabric application type to a cluster.  It is invoked by Visual Studio when deploying a Service Fabric Application project.

.NOTES
WARNING: This script file is invoked by Visual Studio.  Its parameters must not be altered but its logic can be customized as necessary.

.PARAMETER PublishProfileFile
Path to the file containing the publish profile.

.PARAMETER ApplicationPackagePath
Path to the folder of the packaged Service Fabric application.

.PARAMETER DeloyOnly
Indicates that the Service Fabric application should not be created or upgraded after registering the application type.

.PARAMETER ApplicationParameter
Hashtable of the Service Fabric application parameters to be used for the application.

.PARAMETER UnregisterUnusedApplicationVersionsAfterUpgrade
Indicates whether to unregister any unused application versions that exist after an upgrade is finished. However, it will always preserve the last version.

.PARAMETER OverrideUpgradeBehavior
Indicates the behavior used to override the upgrade settings specified by the publish profile. This is only valid for Action : Upgrade
'None' indicates that upgrade will occur with default settings as Monitored if the PublishProfile does not contain the Upgrade Behavior
'ForceUpgrade' indicates that an upgrade will occur with default settings as UnmonitoredAuto if the PublishProfile does not contain the Upgrade Behavior.

.PARAMETER UseExistingClusterConnection
Indicates that the script should make use of an existing cluster connection that has already been established in the PowerShell session.  The cluster connection parameters configured in the publish profile are ignored.

.PARAMETER Action
Service Package deployment action : 'Create', 'Upgrade' and 'Register'
'Register' will only register the Application Package, and do not create or upgrade the Application.
'Create' will create the Application Instance with the name provided in the Applicaiton Parameter file or in the parameter 'ApplicationName'.
'Upgrade' will upgrade the Application Instance with the target ApplicaitonTypeVersion as mentioned in the Application Manifest file.

.PARAMETER OverwriteBehavior
Overwrite Behavior if an application exists in the cluster with the same name. Available Options are Never, Soft, Hard.
'Never' will not remove the existing application or the Target ApplicationType and ApplicationTypeVersion. This is the default behavior.
'Soft' will unregister the TargetApplicationType and Version iff there is no Application using it, and re-register the target ApplicationType and ApplicationTypeVersion
'Hard' will remove the all the Applications, if any, associated with the Target ApplicationType and ApplicationTypeVersion. Unregister the TargetApplicationType and Version, and Reregister it.

.PARAMETER SecurityToken
A security token for authentication to cluster management endpoints. Used for silent authentication to clusters that are protected by Azure Active Directory.

.EXAMPLE

Upgrade/Create with version compatibility check
Use this for Engineering Env
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Auto' -OverrideUpgradeBehavior 'ForceUpgrade' -OverwriteBehavior 'Never' -SecurityToken $securityToken

Upgrade with UnmonitoredAuto, for non Production Upgrade scenario
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Upgrade' -OverrideUpgradeBehavior 'ForceUpgrade' -OverwriteBehavior 'Never' -SecurityToken $securityToken

Upgrade with MonitoredAuto, for Prouction Upgrade scenario
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Upgrade' -OverrideUpgradeBehavior 'None' -OverwriteBehavior 'Never' -SecurityToken $securityToken

Register only with overwrite as Never
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Register' -OverwriteBehavior 'Never' -SecurityToken $securityToken

Register only with safe Overwrite(Soft)
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Register' -OverwriteBehavior 'Soft' -SecurityToken $securityToken

Register only with Hard Overwrite (removes the existing target package even if it is being used.)
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Register' -OverwriteBehavior 'Hard' -SecurityToken $securityToken

Create Application with overwrite as never (does not re-register the package if already exists.)
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Create' -OverwriteBehavior 'Never' -SecurityToken $securityToken

Create Application with overwrite as Soft (Re-registers the package before App creation, if not being used by any App)
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Create' -OverwriteBehavior 'Soft' -SecurityToken $securityToken

Create Application with overwrite as Hard (removes the apps, if any, associated with the Target Package, re-register the package before App creation.)
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -Action 'Create' -OverwriteBehavior 'Hard' -SecurityToken $securityToken

Default  Behaviour: Upgrade, with OverwriteBehavior as never, and Upgrade behavior as None(monitored upgrade)
.\ServiceFabric\Deploy-FabricApplication-Secure.ps1 -PublishProfileFile $ENV:Publish_Profile_FilePath -ApplicationPackagePath 'Release' -SecurityToken $securityToken

#>

Param
(
    [String]
    $PublishProfileFile,

    [String]
    $ApplicationPackagePath,

    [Hashtable]
    $ApplicationParameter,

    [String]
    $ApplicationName,

    [Boolean]
    $UnregisterUnusedApplicationVersionsAfterUpgrade = $true,

    [String]
    [ValidateSet('Register', 'Upgrade', 'Create','Auto')]
    $Action = 'Upgrade',

    [String]
    [ValidateSet('None', 'ForceUpgrade')]
    $OverrideUpgradeBehavior = 'None',

    [Switch]
    $UseExistingClusterConnection,

    [String]
    [ValidateSet('Never','Soft','Hard')]
    $OverwriteBehavior = 'Never',

    [String]
    $SecurityToken 
)


function Master-DeployServiceFabricApplication
{

[CmdletBinding(DefaultParameterSetName="ApplicationName")]  
    Param
    (
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationName")]
        [String]$ApplicationPackagePath,
    
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationParameterFilePath")]
        [String]$ApplicationParameterFilePath,    

        [Parameter(Mandatory=$true,ParameterSetName="ApplicationName")]
        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [String]$ApplicationName,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Hashtable]$ApplicationParameter,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [ValidateSet('Register','Create','Upgrade','Auto')]
        [String]$Action = 'Upgrade',

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [ValidateSet('Never','Soft','Hard')]
        [String]$OverwriteBehavior = 'Soft',

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Hashtable]$UpgradeParameters = @{UnmonitoredAuto = $true},

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Switch]$UnregisterUnusedVersions
        
    )

    if (!(Test-Path $ApplicationPackagePath))
    {
        $errMsg = "$ApplicationPackagePath is not found."
        throw $errMsg
    }

    # Check if the ApplicationPackagePath points to a compressed package.
    if (Test-Path $ApplicationPackagePath -PathType Leaf)
    {
        if((Get-Item $ApplicationPackagePath).Extension -eq ".sfpkg")
        {
            $AppPkgPathToUse=[io.path]::combine($env:Temp, (Get-Item $ApplicationPackagePath).BaseName)
            Expand-ToFolder $ApplicationPackagePath $AppPkgPathToUse
        }
        else
        {
            $errMsg = "$ApplicationPackagePath is not a valid Service Fabric application package"
            throw $errMsg
        }
    }
    else
    {
        $AppPkgPathToUse = $ApplicationPackagePath
    }

    if ($PSBoundParameters.ContainsKey('ApplicationParameterFilePath') -and !(Test-Path $ApplicationParameterFilePath -PathType Leaf))
    {
        $errMsg = "$ApplicationParameterFilePath is not found."
        throw $errMsg
    }

    $packageValidationSuccess = (Test-ServiceFabricApplicationPackage $AppPkgPathToUse)
    if (!$packageValidationSuccess)
    {
        $errMsg = "Validation failed for package: " +  $ApplicationPackagePath
        throw $errMsg
    }

    $ApplicationManifestPath = "$AppPkgPathToUse\ApplicationManifest.xml"

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to Verify connection to Service Fabric cluster."
        throw
    }

    $names = Get-NamesFromApplicationManifest -ApplicationManifestPath $ApplicationManifestPath
    if (!$names)
    {
        Write-Warning "Unable to read Application Type and Version from application manifest file."
        return
    }

    ##Strictly for Register Package
    if($Action -eq "Register"){
        #Get the ApplicationType
        $registeredAppType = Get-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName | Where-Object  { $_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion }  
        
        if($registeredAppType)
        {
            write-host "Target ApplicationTypeName and ApplicationTypeVersion is already registered."

            if($OverwriteBehavior -eq "Never")
            {
                Write-host "Use 'OverwriteBehavior' as 'Soft' or 'Hard' to re register the package that is already registered with the same ApplicationTypeName and ApplicationTypeVersion."
                $errMsg = "Registered ApplicationType and ApplicationTypeVersion can not be re-registed With 'OverwriteBehavior' as 'Never'."
                throw $errMsg
            }

            $appWithTargetAppTypeAndVersion = Get-ServiceFabricApplication | Where-Object {$_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion -and $_.ApplicationTypeName -eq $names.ApplicationTypeName}
            
            if(($OverwriteBehavior -eq "Soft") -and ($appWithTargetAppTypeAndVersion.Count -gt 0))
            {
                Write-host "Use 'OverwriteBehavior' as 'Hard' to re register the package that is already registered with the same ApplicationTypeName and ApplicationTypeVersion."
                $errMsg = "One or more application is using the target ApplicationType and ApplicationTypeVersion. Registered ApplicationType and ApplicationTypeVersion can not be re-registed With 'OverwriteBehavior' as 'Soft'."
                throw $errMsg
            
            }
            
            if(($OverwriteBehavior -eq "Hard") -and ($appWithTargetAppTypeAndVersion.Count -gt 0))
            {
                Write-Host "One or more Application is using the Target ApplicationType and ApplicaitonTypeVersion. Removing all the applications associated with the Target ApplicationType and Version as the OverwriteBehavior is 'Hard'."
                #Remove all the applications associated with the existing AppType and Version
                foreach($app in $appWithTargetAppTypeAndVersion)
                {
                    if($app -and $app.ApplicationName)
                    {
                        Unpublish-ServiceFabricApplication -ApplicationName $app.ApplicationName
                    }
                }
            }

            if((($OverwriteBehavior -eq "Soft") -and ($appWithTargetAppTypeAndVersion.Count -eq 0)) -or ($OverwriteBehavior -eq "Hard"))
            {
                #Unregister the already registered target ApplicationType and Version as there is no Associated App instance with it.
                Write-Host "Unregistering the existing ApplicationType and Version."
                Unregister-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName -ApplicationTypeVersion $names.ApplicationTypeVersion -Force

                #Register the Target ApplicationType and the version.
                Register-ApplicationTypePackage -ApplicationPackagePath $AppPkgPathToUse -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
                Write-Host "Target ApplicationType and version is registered successfully."

            }
            
        }
        else
        {
            #Register the Target AppType and Version
            Register-ApplicationTypePackage -ApplicationPackagePath $AppPkgPathToUse -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
        
        }

        if($UnregisterUnusedVersions)
        {
            Remove-UnusedApplicationTypePackage -ApplicationTypeName $names.ApplicationTypeName -KeepApplicationTypeVersion $names.ApplicationTypeVersion -ErrorAction Stop
            
        }

        return
    }

    # If ApplicationName is not specified on command line get application name from Application Parameter file.
    if(!$ApplicationName)
    {
       $ApplicationName = Get-ApplicationNameFromApplicationParameterFile $ApplicationParameterFilePath
    }

    $app = Get-ServiceFabricApplication -ApplicationName $ApplicationName

    if($app)
    {
        ##Application Exist with specified name

        ##Check the ApplicationTypeName and Version
        if($app.ApplicationTypeVersion -eq $names.ApplicationTypeVersion -and $app.ApplicationTypeName -eq $names.ApplicationTypeName)
        {

            if($OverwriteBehavior -eq "Never")
            {
                Write-Host "Target Application Instance already exist with Target ApplicationTypeName and ApplicationTypeVersion. It cannot be re-created with 'OverwriteBehavior' as 'Never'."
                $errMsg = "Target Application Instance already exist with Target ApplicationTypeName and ApplicationTypeVersion."
                throw $errMsg
            }

            if($Action -eq "Upgrade")
            {
                $errMsg = "Target Application Instance already exist with Target ApplicationTypeName and ApplicationTypeVersion. It cannot be upgraded to the same AppType and Version."
                throw $errMsg
            }

            $appWithTargetAppTypeAndVersion = Get-ServiceFabricApplication | Where-Object {$_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion -and $_.ApplicationTypeName -eq $names.ApplicationTypeName}

            if($OverwriteBehavior -eq "Hard")
            {
                Write-Host "One or more Application is using the Target ApplicationType and ApplicaitonTypeVersion. Removing all the applications associated with the Target ApplicationType and Version as the OverwriteBehavior is 'Hard'."
                #Remove all the applications associated with the existing AppType and Version
                foreach($appInstance in $appWithTargetAppTypeAndVersion)
                {
                    if($appInstance -and $appInstance.ApplicationName)
                    {
                        Unpublish-ServiceFabricApplication -ApplicationName $appInstance.ApplicationName -ErrorAction Stop
                    }
                }
            }
            elseif(($OverwriteBehavior -eq "Soft") -and ($appWithTargetAppTypeAndVersion.count -eq 1))
            {
                Unpublish-ServiceFabricApplication -ApplicationName $ApplicationName -ErrorAction Stop
            }
            elseif(($OverwriteBehavior -eq "Soft") -and ($appWithTargetAppTypeAndVersion.count -gt 1))
            {
                Write-Host " OverwriteBehavior: 'Soft' does not remove other applications using the target ApplicationTypeVersion. This may fail the re-registering the package which is already registered."
                $errMsg = "Target ApplicationType and ApplicationTypeVersion is being used by other Application instances. Failed to remove associated Application instances with OverwriteBehavior as 'Soft'."
                throw $errMsg
            }

            if(($OverwriteBehavior -eq "Soft") -or ($OverwriteBehavior -eq "Hard"))
            {
                #Unregister the already registered target ApplicationType and Version as there is no Associated App instance with it.
                Write-Host "Unregistering the existing ApplicationType and Version."
                
                Unregister-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName -ApplicationTypeVersion $names.ApplicationTypeVersion -ErrorAction Stop -Force
                if(!$?)
                {
                    throw "Unregistering of existing Application Type was unsuccessful."
                }

                #Register the Target ApplicationType and the version.
                Register-ApplicationTypePackage -ApplicationPackagePath $AppPkgPathToUse -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
                Write-Host "Target ApplicationType and version is registered successfully."

                #Create Application Instance
                Create-ServiceFabricApplicationInstance -ApplicationParameterFilePath $ApplicationParameterFilePath -ApplicationName $ApplicationName -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop

            }
            
        }
        else 
        {
            if($app.ApplicationTypeVersion -ne $names.ApplicationTypeVersion -and $app.ApplicationTypeName -eq $names.ApplicationTypeName)
            {
                Write-Host "Application instance exists with Target ApplicationType but with a different Version."
                #Application Type exists but with a different version

                $registeredAppTypeVersion = Get-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName | Where-Object  { $_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion }  
                #Check Version Compatibility of the in use ApplicationTypeVersion and the target ApplicationTypeVersion
                $isVersionCompatible = Check-ApplicationVersionCompatibility -ExitingPackageVersion $app.ApplicationTypeVersion -TargetPackageVersion $names.ApplicationTypeVersion -ErrorAction Stop
                #Check if the Target ApplicationType and Version is already registered.
                if($registeredAppTypeVersion)
                {
                    #Get the Applications that are using the target ApplicationType and ApplicationTypeVersion.
                    $applicationsWithRegistedAppTypeAndVersion = Get-ServiceFabricApplication | Where-Object {$_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion -and $_.ApplicationTypeName -eq $names.ApplicationTypeName}
                    
                    if(($applicationsWithRegistedAppTypeAndVersion.Count -gt 0) -and ($OverwriteBehavior -eq "Hard"))
                    {
                        foreach($application in $applicationsWithRegistedAppTypeAndVersion)
                        {
                            if($application -and $application.ApplicationName)
                            {
                                Unpublish-ServiceFabricApplication -ApplicationName $application.ApplicationName -ErrorAction Stop
                            }
                        }
                    }

                    if((($applicationsWithRegistedAppTypeAndVersion.Count -eq 0) -and ($OverwriteBehavior -eq "Soft")) -or ($OverwriteBehavior -eq "Hard"))
                    {
                        #Unprovision the existing Application Type Version
                        Unregister-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName -ApplicationTypeVersion $names.ApplicationTypeVersion -ErrorAction Stop -Force

                        #Register the new Target Applicaiton Type Version
                        Register-ApplicationTypePackage -ApplicationPackagePath $AppPkgPathToUse -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
                
                    }

                    if(($OverwriteBehavior -eq "Never") -or ($OverwriteBehavior -eq "Soft") -or ($OverwriteBehavior -eq "Hard"))
                    { 
                        if(($Action -eq "Create") -or (($Action -eq "Auto") -and (!$isVersionCompatible)))
                        {
                            #Remove the existing Application
                            Unpublish-ServiceFabricApplication -ApplicationName $ApplicationName -ErrorAction Stop
                            
                            #Create the App instance with the specified name
                            Create-ServiceFabricApplicationInstance -ApplicationParameterFilePath $ApplicationParameterFilePath -ApplicationName $ApplicationName -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop

                            if($UnregisterUnusedVersions)
                            {
                                Remove-UnusedApplicationTypePackage -ApplicationTypeName $names.ApplicationTypeName -KeepApplicationTypeVersion $app.ApplicationTypeVersion -ErrorAction Stop
                            }
                        }
                        elseif((($Action -eq "Upgrade") -or ($Action -eq "Auto")) -and ($isVersionCompatible))
                        {
                            Upgrade-ServiceFabricApplication -ApplicationManifestPath $ApplicationManifestPath -ApplicationParameterFilePath $ApplicationParameterFilePath -ApplicationName $ApplicationName -ApplicationParameter $ApplicationParameter -UpgradeParameters $UpgradeParameters -ErrorAction Stop -UnregisterUnusedVersions
                        }
                        elseif(($Action -eq "Upgrade") -and (!$isVersionCompatible))
                        {
                            $errMsg = "Target ApplicationTypeVersion is not compatible with the ApplicationTypeVersion used by the existing Application for Rolling upgrade."
                            throw $errMsg
                            
                        }
                    }
                }
                else
                {
                   Register-ApplicationTypePackage -ApplicationPackagePath $AppPkgPathToUse -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
                   
                   if(($Action -eq "Create") -or (($Action -eq "Auto") -and (!$isVersionCompatible)))
                   {
                        #Remove the existing Application
                        Unpublish-ServiceFabricApplication -ApplicationName $ApplicationName -ErrorAction Stop
                            
                        #Create the App instance with the specified name
                        Create-ServiceFabricApplicationInstance -ApplicationParameterFilePath $ApplicationParameterFilePath -ApplicationName $ApplicationName -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop

                        if($UnregisterUnusedVersions)
                        {
                            Remove-UnusedApplicationTypePackage -ApplicationTypeName $names.ApplicationTypeName -KeepApplicationTypeVersion $app.ApplicationTypeVersion -ErrorAction Stop
                        }
                   }
                   elseif((($Action -eq "Upgrade") -or ($Action -eq "Auto")) -and ($isVersionCompatible))
                   { 
                        Upgrade-ServiceFabricApplication -ApplicationManifestPath $ApplicationManifestPath -ApplicationParameterFilePath $ApplicationParameterFilePath -ApplicationName $ApplicationName -ApplicationParameter $ApplicationParameter -UpgradeParameters $UpgradeParameters -ErrorAction Stop -UnregisterUnusedVersions
                   }
                   elseif(($Action -eq "Upgrade") -and (!$isVersionCompatible))
                   {
                        $errMsg = "Target ApplicationTypeVersion is not compatible with the ApplicationTypeVersion used by the existing Application for Rolling upgrade."
                        throw $errMsg
                   }
                }
                
            } 
            elseif($app.ApplicationTypeName -ne $names.ApplicationTypeName)
            {
                #Application Type of the matched application is different from the Application type mentioned in the manifest file.
                
                $errMsg = "An application with name '$ApplicationName' already exists, But it's ApplicationTypeName is different from the ApplicationType name in the Application Manifest file."
                throw $errMsg
            }
        }
    
    } 
    else 
    {
        $registeredAppType = Get-ServiceFabricApplicationType | Where-Object  { $_.ApplicationTypeName -eq $names.ApplicationTypeName }  
        
        #Check if the Target ApplicaitonType and ApplicationTypeVersion already is registred.
        if($registeredAppType -and ($registeredAppType.ApplicationTypeVersion -eq $names.ApplicationTypeVersion))
        {
            $applicationsWithRegistedAppTypeAndVersion = Get-ServiceFabricApplication | Where-Object {$_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion -and $_.ApplicationTypeName -eq $names.ApplicationTypeName}
                
            if(($applicationsWithRegistedAppTypeAndVersion.Count -gt 0) -and ($OverwriteBehavior -eq "Hard"))
            {
                foreach($app in $applicationsWithRegistedAppTypeAndVersion)
                {
                    if($app -and $app.ApplicationName)
                    {
                        Unpublish-ServiceFabricApplication -ApplicationName $app.ApplicationName -ErrorAction Stop
                    }
                }
            }

            if((($applicationsWithRegistedAppTypeAndVersion.Count -eq 0) -and ($OverwriteBehavior -eq "Soft")) -or ($OverwriteBehavior -eq "Hard"))
            {
                #Unprovision the existing Application Type Version
                Unregister-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName -ApplicationTypeVersion $names.ApplicationTypeVersion -ErrorAction Stop -Force

                #Register the new Target Applicaiton Type Version
                Register-ApplicationTypePackage -ApplicationPackagePath $AppPkgPathToUse -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
                
            }

            if(($OverwriteBehavior -eq "Never") -or ($OverwriteBehavior -eq "Soft") -or ($OverwriteBehavior -eq "Hard"))
            {
                #Create the App instance with the specified name
                Create-ServiceFabricApplicationInstance -ApplicationParameterFilePath $ApplicationParameterFilePath -ApplicationName $ApplicationName -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
                
            }
        } 
        else 
        {
            #Register the AppType and AppTypeVersion
            Register-ApplicationTypePackage -ApplicationPackagePath $AppPkgPathToUse -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop

            #Create Application Instance
            Create-ServiceFabricApplicationInstance -ApplicationParameterFilePath $ApplicationParameterFilePath -ApplicationName $ApplicationName -ApplicationManifestPath $ApplicationManifestPath -ErrorAction Stop
                
        }
    }

}

function Check-ApplicationVersionCompatibility
{
    Param
    (
    [Parameter(Mandatory=$true)]
    [ValidatePattern("^[1-9]+.[0-9]+.[0-9]+")]
    [String]$ExitingPackageVersion,

    [Parameter(Mandatory=$true)]
    [ValidatePattern("^[1-9]+.[0-9]+.[0-9]+")]
    [String]$TargetPackageVersion
    )

   $versionArrayExisting = $ExitingPackageVersion.Split('.')
   $versionArrayTarget = $TargetPackageVersion.Split('.')

   if(($versionArrayExisting[0] -ne $versionArrayTarget[0]) -or ($versionArrayExisting[1] -ne $versionArrayTarget[1]))
   {
    return $false
   }
   else 
   {
    return $true
   }

}

function Remove-UnusedApplicationTypePackage
{

Param
(
    [Parameter(Mandatory=$true)]
    [String]
    $ApplicationTypeName,

    [Parameter(Mandatory=$false)]
    [String]
    $KeepApplicationTypeVersion
)

    if(!$KeepApplicationTypeVersion)
    {
        $KeepApplicationTypeVersion = "-0"
    }

    Write-Host 'Unregistering unused versions for the application type...'
    foreach($registeredAppTypes in Get-ServiceFabricApplicationType -ApplicationTypeName $ApplicationTypeName )
    {
        try
        {
            if($KeepApplicationTypeVersion -ne $registeredAppTypes.ApplicationTypeVersion)
            {
                $registeredAppTypes | Unregister-ServiceFabricApplicationType -Force
            }
                    
        }
        catch [System.Fabric.FabricException]
        {
           # AppType and Version in use.
        }
    }
}

function Register-ApplicationTypePackage
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [String]$ApplicationPackagePath,
    
        [Parameter(Mandatory=$true)]
        [String]$ApplicationManifestPath     
    )

    $names = Get-NamesFromApplicationManifest -ApplicationManifestPath $ApplicationManifestPath
    if (!$names)
    {
        Write-Warning "Unable to read Application Type and Version from application manifest file."
        return
    }

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to Verify connection to Service Fabric cluster."

    }
      

    
    Write-Host 'Copying application to image store...'
    # Get image store connection string
    $clusterManifestText = Get-ServiceFabricClusterManifest
    $imageStoreConnectionString = Get-ImageStoreConnectionStringFromClusterManifest ([xml] $clusterManifestText)

    $applicationPackagePathInImageStore = $names.ApplicationTypeName
    Copy-ServiceFabricApplicationPackage -ApplicationPackagePath $ApplicationPackagePath -ImageStoreConnectionString $imageStoreConnectionString -ApplicationPackagePathInImageStore $applicationPackagePathInImageStore -TimeoutSec 1800
    if(!$?)
    {
        throw "Copying of application package to image store failed. Cannot continue with registering the application."
    }

    Write-Host 'Registering application type...'
    Register-ServiceFabricApplicationType -ApplicationPathInImageStore $applicationPackagePathInImageStore -TimeoutSec 600
    if(!$?)
    {
        throw "Registration of application type failed."
    }

    Write-Host 'Removing application package from image store...'
    Remove-ServiceFabricApplicationPackage -ApplicationPackagePathInImageStore $applicationPackagePathInImageStore -ImageStoreConnectionString $imageStoreConnectionString
}

function Create-ServiceFabricApplicationInstance
{

    [CmdletBinding(DefaultParameterSetName="ApplicationName")]  
    Param
    (
    
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationParameterFilePath")]
        [String]$ApplicationParameterFilePath,    

        [Parameter(Mandatory=$true,ParameterSetName="ApplicationName")]
        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [String]$ApplicationName,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Hashtable]$ApplicationParameter,

        [Parameter(Mandatory=$true)]
        [String]$ApplicationManifestPath 
    )

    $names = Get-NamesFromApplicationManifest -ApplicationManifestPath $ApplicationManifestPath
    if (!$names)
    {
        Write-Warning "Unable to read Application Type and Version from application manifest file."
        return
    }

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to Verify connection to Service Fabric cluster."

    }


    Write-Host 'Creating application...'

    # If application parameters file is specified read values from and merge it with parameters passed on Commandline
    if ($PSBoundParameters.ContainsKey('ApplicationParameterFilePath'))
    {
        $appParamsFromFile = Get-ApplicationParametersFromApplicationParameterFile $ApplicationParameterFilePath        
        if(!$ApplicationParameter)
        {
            $ApplicationParameter = $appParamsFromFile
        }
        else
        {
            $ApplicationParameter = Merge-Hashtables -HashTableOld $appParamsFromFile -HashTableNew $ApplicationParameter
        }    
    }
    
    Write-Host $ApplicationName;
	Write-Host $names.ApplicationTypeName;
    Write-Host $names.ApplicationTypeVersion;
	Write-Host $ApplicationParameter;
    New-ServiceFabricApplication -ApplicationName $ApplicationName -ApplicationTypeName $names.ApplicationTypeName -ApplicationTypeVersion $names.ApplicationTypeVersion -ApplicationParameter $ApplicationParameter
    if(!$?)
    {
        throw "Creation of application failed."
    }

    Write-Host 'Create application succeeded.'
}

function Upgrade-ServiceFabricApplication
{
 
    Param
    (

        [Parameter(Mandatory=$true)]
        [String]$ApplicationManifestPath,

        [Parameter(Mandatory=$true)]
        [String]$ApplicationParameterFilePath,

        [Parameter(Mandatory=$true)]
        [String]$ApplicationName,

        [Hashtable]$ApplicationParameter,

        [Hashtable]$UpgradeParameters = @{UnmonitoredAuto = $true},

        [Switch]$UnregisterUnusedVersions
    )

    $names = Get-NamesFromApplicationManifest -ApplicationManifestPath $ApplicationManifestPath
    if (!$names)
    {
        Write-Warning "Unable to read Application Type and Version from application manifest file."
        return
    }

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to Verify connection to Service Fabric cluster."

    }

    ## Check existence of the application
    $oldApplication = Get-ServiceFabricApplication -ApplicationName $ApplicationName
        
    if (!$oldApplication)
    {
        $errMsg = "Application '$ApplicationName' doesn't exist in cluster."
        throw $errMsg
    }
    else
    {
        if($oldApplication.ApplicationTypeName -ne $names.ApplicationTypeName)
        {   
            $errMsg =  "Application type of application '$ApplicationName' doesn't match with the Application Type in application manifest specified in the new application package.
            Please ensure that the application being upgraded is of the same Applciation Type."
            throw $errMsg
        }
    }                
    
    ## Check upgrade status
    $upgradeStatus = Get-ServiceFabricApplicationUpgrade -ApplicationName $ApplicationName
    if ($upgradeStatus.UpgradeState -ne "RollingBackCompleted" -and $upgradeStatus.UpgradeState -ne "RollingForwardCompleted")
    {
        $errMsg = "An upgrade for the application '$names.ApplicationTypeName' is already in progress."
        throw $errMsg
    }

    try
        {
            $UpgradeParameters["ApplicationName"] = $ApplicationName
            $UpgradeParameters["ApplicationTypeVersion"] = $names.ApplicationTypeVersion
        
             # If application parameters file is specified read values from and merge it with parameters passed on Commandline
            if ($PSBoundParameters.ContainsKey('ApplicationParameterFilePath'))
            {
                $appParamsFromFile = Get-ApplicationParametersFromApplicationParameterFile $ApplicationParameterFilePath        
                if(!$ApplicationParameter)
                {
                    $ApplicationParameter = $appParamsFromFile
                }
                else
                {
                    $ApplicationParameter = Merge-Hashtables -HashTableOld $appParamsFromFile -HashTableNew $ApplicationParameter
                }    
            }
     
            $UpgradeParameters["ApplicationParameter"] = $ApplicationParameter

            $serviceTypeHealthPolicyMap = $upgradeParameters["ServiceTypeHealthPolicyMap"]
            if ($serviceTypeHealthPolicyMap -and $serviceTypeHealthPolicyMap -is [string])
            {
                $upgradeParameters["ServiceTypeHealthPolicyMap"] = Invoke-Expression $serviceTypeHealthPolicyMap
            }
        
            Write-Host "Start upgrading application..." 
            Start-ServiceFabricApplicationUpgrade @UpgradeParameters
        }
        catch
        {
            throw
        }

        if (!$UpgradeParameters["Monitored"] -and !$UpgradeParameters["UnmonitoredAuto"])
        {
            return
        }
    
        do
        {
            Write-Host "Waiting for upgrade..."
            Start-Sleep -Seconds 3
            $upgradeStatus = Get-ServiceFabricApplicationUpgrade -ApplicationName $ApplicationName
        } while ($upgradeStatus.UpgradeState -ne "RollingBackCompleted" -and $upgradeStatus.UpgradeState -ne "RollingForwardCompleted")
    
        
        if($UnregisterUnusedVersions)
        {
            Remove-UnusedApplicationTypePackage -ApplicationTypeName $names.ApplicationTypeName -KeepApplicationTypeVersion $oldApplication.ApplicationTypeVersion
        }

        if($upgradeStatus.UpgradeState -eq "RollingForwardCompleted")
        {
            Write-Host "Upgrade completed successfully."
        }
        elseif($upgradeStatus.UpgradeState -eq "RollingBackCompleted")
        {
            Write-Host "Upgrade was Rolled back."
        }
}

function Get-ServiceFabricApplicationStatus
{
    <#
    .SYNOPSIS 
    Outputs messages indicating the readiness of a Service Fabric application.

    .DESCRIPTION
    This script outputs messages indicating the readiness of a Service Fabric application

    .PARAMETER ApplicationName
    Name of the Service Fabric application.

    .EXAMPLE
    Get-FabricApplicationStatus.ps1 -ApplicationName 'fabric:/SampleApp'

    Get the status of a deployed application.
    #>

    Param
    (    
        [String]
        $ApplicationName
    )

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to Verify connection to Service Fabric cluster."
        throw
    }

    $started = $false
    $ready = $false
    $retryCount = 20
    do
    {
        try
        {
            $app = Get-ServiceFabricApplication -ApplicationName $ApplicationName
            if ($app)
            {   
                if (!$started)
                {
                    $started = $true
                    Write-Host "The application has started."
                }

                $ready = $true
                Write-Host "Service Status:"
                $services = $app | Get-ServiceFabricService
                foreach($s in $services)
                {
                    $remaining = $s | Get-ServiceFabricPartition | Where-Object {$_.PartitionStatus -ne "Ready"} | Measure
                    if($remaining.Count -gt 0)
                    {
                        $ready = $false
                        Write-Host "$($s.ServiceName) is not ready, $($remaining.Count) partitions remaining."
                    }
                    else
                    {
                        Write-Host "$($s.ServiceName) is ready."
                    }
                }
            }
            else
            {
                Write-Host "Waiting for the application to start."
            }
            Write-Host ""
        }
        finally
        {
            if(!$ready)
            {
                Start-Sleep -Seconds 5
            }
            $retryCount--
        }
    } while (!$ready -and $retryCount -gt 0)

    if(!$ready)
    {
        Write-Host "Something is taking too long, the application is still not ready."
    }
    else
    {
        Write-Host "The application is ready."
    }
}

function New-ServiceFabricApplicationPackage
{
    <#
    .SYNOPSIS 
    Creates a .sfpkg file from an existing Service Fabric application package directory.

    .DESCRIPTION
    Creates a .sfpkg file from an existing Service Fabric application package directory. A valid .sfpkg can the be published to Service Fabric Cluster.
    
    .PARAMETER ApplicationPackagePath
    Path to the folder containing the Service Fabric application package.
    
    .PARAMETER SFpkgName
    Name of the .sfpkg file to be created.
    
    .PARAMETER SFpkgOutputPath
    Path where you want the .sfpkg file to be placed.  
    
    .PARAMETER $Force
    Replace file if it already exists. 

    .EXAMPLE
    Create-ServiceFabricApplicationPackage -ApplicationPackagePath 'pkg\Debug' -SFpkgName 'MyAppV1'

    Creates a MyAppV1.sfpkg file.  

    Create-ServiceFabricApplicationPackage -ApplicationPackagePath 'pkg\Debug' -SFpkgName 'MyAppV1' -SFpkgOutputPath 'C:\ServiceFabricApplicationPackages'

    Creates a MyAppV1.sfpkg file, and places it in the output path 'C:\ServiceFabricApplicationPackages'

    #>
    
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)]
        [String]$ApplicationPackagePath,
        
        [Parameter(Mandatory=$true)]
        [String]$SFpkgName,
        
        [Parameter()]
        [String]$SFpkgOutputPath = (Get-Location),

        [Parameter()]
        [switch] $Force
        
    )

    
    if (!(Test-Path $ApplicationPackagePath))
    {
        $errMsg = "ApplicationPackagePath is not found."
        throw $errMsg
    }
    if (Test-Path $ApplicationPackagePath -PathType Leaf)
    {
        $errMsg = "$ApplicationPackagePath must be a path to a directory."
        throw $errMsg
    }
    
    $packageValidationSuccess = (Test-ServiceFabricApplicationPackage $ApplicationPackagePath)
    if (!$packageValidationSuccess)
    {
       $errMsg = "Validation failed for package: " +  $ApplicationPackagePath
       throw $errMsg
    }
    
    $invalidFileNamepattern = "[{0}]" -f ([Regex]::Escape( [System.IO.Path]::GetInvalidFileNameChars() -join '' ))
    if($SFpkgName -match $invalidFileNamepattern)
    {
       $errMsg = "SFpkgName has some invalid characters: " +  $SFpkgName
       throw $errMsg
    }
    if (!(Test-Path $SFpkgOutputPath))
    {
        $errMsg = "SFpkgOutputPath is not found."
        throw $errMsg
    }
    if (Test-Path $SFpkgOutputPath -PathType Leaf)
    {
        $errMsg = "$SFpkgOutputPath must be a path to a directory."
        throw $errMsg
    }

    $SFpkgPath = (Convert-Path $SFpkgOutputPath) + "\" + $SFpkgName + ".sfpkg"

    if (Test-Path $SFpkgPath -PathType Leaf)
    {
      $SFpkgPathFormatted = Convert-Path $SFpkgPath
      if(-Not $Force)
      {
          [ValidateSet('Y','N')]$ReplaceFile = Read-Host $SFpkgPathFormatted " already exists. Do you want to replace it? (Y/N)"
          if($ReplaceFile.ToLower().Contains("n"))
          {
            return
          }
      }
      Remove-Item $SFpkgPathFormatted
    }

    Compress-ToFile $ApplicationPackagePath $SFpkgPath
}

function Remove-ServiceFabricApplicationType
{
<#
.SYNOPSIS 
Removes all the applciations for the specified service fabric application type & version and unregisters thea applicaiton type and version.

.DESCRIPTION
Removes all the applciations for the specified service fabric application type & version and unregisters thea applicaiton type and version.

.NOTES
WARNING: This script file is invoked by Visual Studio.  Its parameters must not be altered.

.PARAMETER ApplicationTypeName
The name of the application type to remove.

.PARAMETER ApplicationTypeVersion
The version of the application type to remove.

.EXAMPLE
Remove-ApplicationType.ps1 -ApplicationTypeName 'MyApplicationType' -ApplicationTypeVersion '1.0.0.0'
#>

Param
(
    [Parameter(Mandatory=$true)]
    [String]
    $ApplicationTypeName,

    [Parameter(Mandatory=$true)]
    [String]
    $ApplicationTypeVersion
)


Write-Host "Removing application type..."

try
{
    [void](Test-ServiceFabricClusterConnection)
}
catch
{
    Write-Warning "Unable to Verify connection to Service Fabric cluster."
    throw
}

$nodes = Get-ServiceFabricNode
foreach ($app in Get-ServiceFabricApplication)
{
    if ($app.ApplicationTypeName -eq $ApplicationTypeName -and $app.ApplicationTypeVersion -eq $ApplicationTypeVersion)
    {
		try
		{
            $app | Remove-ServiceFabricApplication -Force
		}
	    catch [System.TimeoutException]
        {
	        # Catch operation timeout and continue with force remove replica.
        }

        foreach ($node in $nodes)
        {
            [void](Get-ServiceFabricDeployedReplica -NodeName $node.NodeName -ApplicationName $app.ApplicationName | Remove-ServiceFabricReplica -NodeName $node.NodeName -ForceRemove)
        }
    }
}

$reg = Get-ServiceFabricApplicationType -ApplicationTypeName $ApplicationTypeName | Where-Object { $_.ApplicationTypeVersion -eq $ApplicationTypeVersion }
if ($reg)
{
    $reg | Unregister-ServiceFabricApplicationType -ApplicationTypeVersion $ApplicationTypeVersion -Force
}

Write-Host "Finished removing the application type"

}

function Unpublish-ServiceFabricApplication
{

<#
.SYNOPSIS 
Removes the specified service fabric application

.DESCRIPTION
This script removes the application.

.NOTES
This will forcefully Removes all the replicsa for the specified service fabric application.

.PARAMETER ApplicationName
The name of the application type to remove.

.EXAMPLE
Remove-Application.ps1 -ApplicationName 'fabric:/MyApplication'
#>

Param
(
    [Parameter(Mandatory=$true)]
    [String]
    $ApplicationName
)


Write-Host "Removing application..."

try
{
    [void](Test-ServiceFabricClusterConnection)
}
catch
{
    Write-Warning "Unable to Verify connection to Service Fabric cluster."
    throw
}

$app = Get-ServiceFabricApplication -ApplicationName $ApplicationName
if ($app)
{
	try
	{
		$app | Remove-ServiceFabricApplication -Force
	}
	catch [System.TimeoutException]
    {
	    # Catch operation timeout and continue with force remove replica.
    }
}

foreach ($node in Get-ServiceFabricNode)
{
    [void](Get-ServiceFabricDeployedReplica -NodeName $node.NodeName -ApplicationName $ApplicationName | Remove-ServiceFabricReplica -NodeName $node.NodeName -ForceRemove)
}

}

function Copy-ToTemp
{
    <#
    .SYNOPSIS 
    Copies files to a temp folder.

    .PARAMETER From
    Source location from which to copy files.

    .PARAMETER Name
    Folder name within temp location to store the files.
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $From,
        
        [String]
        $Name
    )

    if (!(Test-Path $From))
    {
        return $null
    }

    $To = $env:Temp + '\' + $Name
    
    if (Test-Path $To)
    {
        Remove-Item -Path $To -Recurse -ErrorAction Stop | Out-Null
    }

    New-Item $To -ItemType directory | Out-Null

    robocopy "$From" "$To" /E /MT | Out-Null

    # robocopy has non-standard exit values that are documented here: https://support.microsoft.com/en-us/kb/954404
    # Exit codes 0-8 are considered success, while all other exit codes indicate at least one failure.
    # Some build systems treat all non-0 return values as failures, so we massage the exit code into
    # something that they can understand.
    if (($LASTEXITCODE -ge 0) -and ($LASTEXITCODE -le 8))
    {
        # Simply setting $LASTEXITCODE in this script will not override the script's exit code.
        # We need to start a new process and let it exit.
        PowerShell -NoProfile -Command "exit 0"
    }

    return $env:Temp + '\' + $Name
}

function Expand-ToFolder
{
    <#
    .SYNOPSIS 
    Unzips the zip file to the specified folder.

    .PARAMETER From
    Source location to unzip

    .PARAMETER Name
    Folder name to expand the files to.
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $File,
        
        [String]
        $Destination
    )

    if (!(Test-Path $File))
    {
        return
    }    
    
    if (Test-Path $Destination)
    {
        Remove-Item -Path $Destination -Recurse -ErrorAction Stop | Out-Null
    }

    New-Item $Destination -ItemType directory | Out-Null


    Write-Verbose -Message "Attempting to Unzip $File to location $Destination" 
    try 
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null 
        [System.IO.Compression.ZipFile]::ExtractToDirectory("$File", "$Destination") 
    } 
    catch 
    { 
        Write-Error -Message "Unexpected Error. Error details: $_.Exception.Message" 
    } 
}

function Compress-ToFile
{
   <#
    .SYNOPSIS 
    Compress the Source Directory to a zip file.

    .PARAMETER SourceDir
    Path of the directory to zip

    .PARAMETER FileName
    Name of the zip file to generate. 
    #>
    
   [CmdletBinding()]
    Param
    (
        [String]
        $SourceDir,
        
        [String]
        $FileName
    )
    
    if (!(Test-Path $SourceDir))
    {
        return
    }  
    
    try 
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null 
        $compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
        [System.IO.Compression.ZipFile]::CreateFromDirectory($SourceDir,$FileName, $compressionLevel, $false)
    }
    catch 
    { 
        Write-Error -Message "Unexpected Error. Error details: $_.Exception.Message" 
    } 
}

function Get-NamesFromApplicationManifest
{
    <#
    .SYNOPSIS 
    Returns an object containing common information from the application manifest.

    .PARAMETER ApplicationManifestPath
    Path to the application manifest file.    
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $ApplicationManifestPath
    )

    if (!(Test-Path $ApplicationManifestPath))
    {
        throw "$ApplicationManifestPath is not found."
    }

    
    $appXml = [xml] (Get-Content $ApplicationManifestPath)
    if (!$appXml)
    {
        return
    }

    $appMan = $appXml.ApplicationManifest
    $FabricNamespace = 'fabric:'
    $appTypeSuffix = 'Type'

    $h = @{
        FabricNamespace = $FabricNamespace;
        ApplicationTypeName = $appMan.ApplicationTypeName;
        ApplicationTypeVersion = $appMan.ApplicationTypeVersion;
    }   

    Write-Output (New-Object psobject -Property $h)
}

function Get-ImageStoreConnectionStringFromClusterManifest
{
    <#
    .SYNOPSIS 
    Returns the value of the image store connection string from the cluster manifest.

    .PARAMETER ClusterManifest
    Contents of cluster manifest file.
    #>

    [CmdletBinding()]
    Param
    (
        [xml]
        $ClusterManifest
    )

    $managementSection = $ClusterManifest.ClusterManifest.FabricSettings.Section | ? { $_.Name -eq "Management" }
    return $managementSection.ChildNodes | ? { $_.Name -eq "ImageStoreConnectionString" } | Select-Object -Expand Value
}

function Get-ApplicationNameFromApplicationParameterFile
{
    <#
    .SYNOPSIS 
    Returns Application Name from ApplicationParameter xml file.

    .PARAMETER ApplicationParameterFilePath
    Path to the application parameter file
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $ApplicationParameterFilePath
    )
    
    if (!(Test-Path $ApplicationParameterFilePath))
    {
        $errMsg = "$ApplicationParameterFilePath is not found."
        throw $errMsg
    }

    return ([xml] (Get-Content $ApplicationParameterFilePath)).Application.Name
}

function Get-ApplicationParametersFromApplicationParameterFile
{
    <#
    .SYNOPSIS 
    Reads ApplicationParameter xml file and returns HashTable containing ApplicationParameters.

    .PARAMETER ApplicationParameterFilePath
    Path to the application parameter file
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $ApplicationParameterFilePath
    )
    
    if (!(Test-Path $ApplicationParameterFilePath))
    {
        throw "$ApplicationParameterFilePath is not found."
    }
    
    $ParametersXml = ([xml] (Get-Content $ApplicationParameterFilePath)).Application.Parameters

    $hash = @{}
    $ParametersXml.ChildNodes | foreach {
       if ($_.LocalName -eq 'Parameter') {
       $hash[$_.Name] = $_.Value
       }
    }

    return $hash
}

function Merge-HashTables
{
    <#
    .SYNOPSIS 
    Merges 2 hashtables. Key, value pairs form HashTableNew are preserved if any duplciates are found between HashTableOld & HashTableNew.

    .PARAMETER HashTableOld
    First Hashtable.
    
    .PARAMETER HashTableNew
    Second Hashtable 
    #>

    [CmdletBinding()]
    Param
    (
        [HashTable]
        $HashTableOld,
        
        [HashTable]
        $HashTableNew
    )
    
    $keys = $HashTableOld.getenumerator() | foreach-object {$_.key}
    $keys | foreach-object {
        $key = $_
        if ($HashTableNew.containskey($key))
        {
            $HashTableOld.remove($key)
        }
    }
    $HashTableNew = $HashTableOld + $HashTableNew
    return $HashTableNew
}

function Read-XmlElementAsHashtable
{
    Param (
        [System.Xml.XmlElement]
        $Element
    )

    $hashtable = @{}
    if ($Element.Attributes)
    {
        $Element.Attributes | 
            ForEach-Object {
                $boolVal = $null
                if ([bool]::TryParse($_.Value, [ref]$boolVal)) {
                    $hashtable[$_.Name] = $boolVal
                }
                else {
                    $hashtable[$_.Name] = $_.Value
                }
            }
    }

    return $hashtable
}

function Read-PublishProfile
{
    Param (
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [String]
        $PublishProfileFile
    )

    $publishProfileXml = [Xml] (Get-Content $PublishProfileFile)
    $publishProfile = @{}

    $publishProfile.ClusterConnectionParameters = Read-XmlElementAsHashtable $publishProfileXml.PublishProfile.Item("ClusterConnectionParameters")
    $publishProfile.UpgradeDeployment = Read-XmlElementAsHashtable $publishProfileXml.PublishProfile.Item("UpgradeDeployment")

    if ($publishProfileXml.PublishProfile.Item("UpgradeDeployment"))
    {
        $publishProfile.UpgradeDeployment.Parameters = Read-XmlElementAsHashtable $publishProfileXml.PublishProfile.Item("UpgradeDeployment").Item("Parameters")
        if ($publishProfile.UpgradeDeployment["Mode"])
        {
            $publishProfile.UpgradeDeployment.Parameters[$publishProfile.UpgradeDeployment["Mode"]] = $true
        }
    }

    $publishProfileFolder = (Split-Path $PublishProfileFile)
    $publishProfile.ApplicationParameterFile = [System.IO.Path]::Combine($PublishProfileFolder, $publishProfileXml.PublishProfile.ApplicationParameterFile.Path)

    return $publishProfile
}

$LocalFolder = (Split-Path $MyInvocation.MyCommand.Path)

if (!$PublishProfileFile)
{
    $PublishProfileFile = "$LocalFolder\..\PublishProfiles\Local.xml"
}

if (!$ApplicationPackagePath)
{
    $ApplicationPackagePath = "$LocalFolder\..\pkg\Release"
}

$ApplicationPackagePath = Resolve-Path $ApplicationPackagePath

$publishProfile = Read-PublishProfile $PublishProfileFile

if (-not $UseExistingClusterConnection)
{
    $ClusterConnectionParameters = $publishProfile.ClusterConnectionParameters
    if ($SecurityToken)
    {
        $ClusterConnectionParameters["SecurityToken"] = $SecurityToken
    }

    try
    {
        [void](Connect-ServiceFabricCluster @ClusterConnectionParameters)
        $global:clusterConnection = $clusterConnection
    }
    catch [System.Fabric.FabricObjectClosedException]
    {
        Write-Warning "Service Fabric cluster may not be connected."
        throw
    }
}

#$RegKey = "HKLM:\SOFTWARE\Microsoft\Service Fabric SDK"
#$ModuleFolderPath = (Get-ItemProperty -Path $RegKey -Name FabricSDKPSModulePath).FabricSDKPSModulePath
#Import-Module "$ModuleFolderPath\ServiceFabricSDK.psm1"

$upgradeWithPublishProfile = ($publishProfile.UpgradeDeployment -and $publishProfile.UpgradeDeployment.Enabled)
if($upgradeWithPublishProfile)
{
    #Upgrade with upgrade info provided in the PublishProfile.
    $Action = "Upgrade"
    $UpgradeParameters = $publishProfile.UpgradeDeployment.Parameters

}
else 
{
    if(($Action -eq "Upgrade") -or ($Action -eq "Auto") )
    {
        #Upgrade with the default behavior 
        #OverrideUpgradeBehavior: ForceUpgrade will upgrade with 'Unmonitored'
        #OverrideUpgradeBehavior: None will upgrade with 'Monitored'. This is preferred for Production Environment.

        if ($OverrideUpgradeBehavior -eq 'ForceUpgrade')
        {
            # Warning: Do not alter these upgrade parameters. It will create an inconsistency with Visual Studio's behavior.
            $UpgradeParameters = @{ UnmonitoredAuto = $true; Force = $true }
        }
        else
        {
            $UpgradeParameters = @{ Monitored = $true; HealthCheckStableDurationSec = 60; UpgradeDomainTimeoutSec = 1200; UpgradeTimeout = 3000; FailureAction = 'Rollback' }
        }
    }
}


if($ApplicationName)
{
    Master-DeployServiceFabricApplication -ApplicationPackagePath $ApplicationPackagePath -ApplicationParameterFilePath $publishProfile.ApplicationParameterFile -ApplicationParameter $ApplicationParameter -UpgradeParameters $UpgradeParameters -UnregisterUnusedVersions:$UnregisterUnusedApplicationVersionsAfterUpgrade -Action $Action -OverwriteBehavior $OverwriteBehavior -ApplicationName $ApplicationName -ErrorAction Stop
}
else
{
    Master-DeployServiceFabricApplication -ApplicationPackagePath $ApplicationPackagePath -ApplicationParameterFilePath $publishProfile.ApplicationParameterFile -ApplicationParameter $ApplicationParameter -UpgradeParameters $UpgradeParameters -UnregisterUnusedVersions:$UnregisterUnusedApplicationVersionsAfterUpgrade -Action $Action -OverwriteBehavior $OverwriteBehavior -ErrorAction Stop
}



