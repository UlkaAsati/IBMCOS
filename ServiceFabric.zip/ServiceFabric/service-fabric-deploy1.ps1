﻿pause
Import-Module "$ENV:ProgramFiles\Microsoft SDKs\Service Fabric\Tools\PSModule\ServiceFabricSDK\ServiceFabricSDK.psm1"

$cep = 'apttus-sf-1.westus.cloudapp.azure.com:19000'
#explorer http://apttus-sf-1.westus.cloudapp.azure.com:19080/Explorer

#package the SF service in VS
#copy to a tmp dir
Connect-ServiceFabricCluster -ConnectionEndpoint $cep
cd C:\tmp

Copy-ServiceFabricApplicationPackage -ApplicationPackagePath C:\tmp\StafefullySF -ImageStoreConnectionString (Get-ImageStoreConnectionStringFromClusterManifest(Get-ServiceFabricClusterManifest))
#Remove-ServiceFabricApplicationPackage -ApplicationPackagePathInImageStore Stateful1Pkg -ImageStoreConnectionString (Get-ImageStoreConnectionStringFromClusterManifest(Get-ServiceFabricClusterManifest))
Register-ServiceFabricApplicationType StafefullySF

Get-ServiceFabricApplicationType

#not working
#New-ServiceFabricApplication fabric:/MyApp StafefullySF AppManifestVersion1

