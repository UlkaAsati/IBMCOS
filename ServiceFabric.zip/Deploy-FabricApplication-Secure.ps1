﻿<#
.SYNOPSIS 
Deploys a Service Fabric application type to a cluster.

.DESCRIPTION
This script deploys a Service Fabric application type to a cluster.  It is invoked by Visual Studio when deploying a Service Fabric Application project.

.NOTES
WARNING: This script file is invoked by Visual Studio.  Its parameters must not be altered but its logic can be customized as necessary.

.PARAMETER PublishProfileFile
Path to the file containing the publish profile.

.PARAMETER ApplicationPackagePath
Path to the folder of the packaged Service Fabric application.

.PARAMETER DeloyOnly
Indicates that the Service Fabric application should not be created or upgraded after registering the application type.

.PARAMETER ApplicationParameter
Hashtable of the Service Fabric application parameters to be used for the application.

.PARAMETER UnregisterUnusedApplicationVersionsAfterUpgrade
Indicates whether to unregister any unused application versions that exist after an upgrade is finished.

.PARAMETER OverrideUpgradeBehavior
Indicates the behavior used to override the upgrade settings specified by the publish profile.
'None' indicates that the upgrade settings will not be overriden.
'ForceUpgrade' indicates that an upgrade will occur with default settings, regardless of what is specified in the publish profile.
'VetoUpgrade' indicates that an upgrade will not occur, regardless of what is specified in the publish profile.

.PARAMETER UseExistingClusterConnection
Indicates that the script should make use of an existing cluster connection that has already been established in the PowerShell session.  The cluster connection parameters configured in the publish profile are ignored.

.PARAMETER OverwriteBehavior
Overwrite Behavior if an application exists in the cluster with the same name. Available Options are Never, Always, SameAppTypeAndVersion. This setting is not applicable when upgrading an application.
'Never' will not remove the existing application. This is the default behavior.
'Always' will remove the existing application even if its Application type and Version is different from the application being created. 
'SameAppTypeAndVersion' will remove the existing application only if its Application type and Version is same as the application being created.

.PARAMETER SkipPackageValidation
Switch signaling whether the package should be validated or not before deployment.

.PARAMETER SecurityToken
A security token for authentication to cluster management endpoints. Used for silent authentication to clusters that are protected by Azure Active Directory.

.EXAMPLE
. Scripts\Deploy-FabricApplication.ps1 -ApplicationPackagePath 'pkg\Debug'

Deploy the application using the default package location for a Debug build.

.EXAMPLE
. Scripts\Deploy-FabricApplication.ps1 -ApplicationPackagePath 'pkg\Debug' -DoNotCreateApplication

Deploy the application but do not create the application instance.

.EXAMPLE
. Scripts\Deploy-FabricApplication.ps1 -ApplicationPackagePath 'pkg\Debug' -ApplicationParameter @{CustomParameter1='MyValue'; CustomParameter2='MyValue'}

Deploy the application by providing values for parameters that are defined in the application manifest.
#>

Param
(
    [String]
    $PublishProfileFile,

    [String]
    $ApplicationPackagePath,

    [Switch]
    $DeployOnly,

    [Hashtable]
    $ApplicationParameter,

    [Boolean]
    $UnregisterUnusedApplicationVersionsAfterUpgrade,

    [String]
    [ValidateSet('None', 'ForceUpgrade', 'VetoUpgrade')]
    $OverrideUpgradeBehavior = 'None',

    [Switch]
    $UseExistingClusterConnection,

    [String]
    [ValidateSet('Never','Always','SameAppTypeAndVersion')]
    $OverwriteBehavior = 'Never',

    [Switch]
    $SkipPackageValidation,

    [String]
    $SecurityToken 
)





function Publish-NewServiceFabricApplication
{
    <#
    .SYNOPSIS 
    Publishes a new Service Fabric application type to Service Fabric cluster.

    .DESCRIPTION
    This script registers & creates a Service Fabric application.

    .NOTES
    Connection to service fabric cluster should be established by using 'Connect-ServiceFabricCluster' before invoking this cmdlet.
    WARNING: This script creates a new Service Fabric application in the cluster. If OverwriteExistingApplication switch is provided, it deletes any existing application in the cluster with the same name.

    .PARAMETER ApplicationPackagePath
    Path to the folder containing the Service Fabric application package OR path to the zipped service fabric applciation package.

    .PARAMETER ApplicationParameterFilePath
    Path to the application parameter file which contains Application Name and application parameters to be used for the application.    

    .PARAMETER ApplicationName
    Name of Service Fabric application to be created. If value for this parameter is provided alongwith ApplicationParameterFilePath it will override the Application name specified in ApplicationParameter  file.

    .PARAMETER Action
    Action which this script performs. Available Options are Register, Create, RegisterAndCreate. Default Action is RegisterAndCreate.

    .PARAMETER ApplicationParameter
    Hashtable of the Service Fabric application parameters to be used for the application. If value for this parameter is provided, it will be merged with application parameters
    specified in ApplicationParameter file. In case a parameter is found in application parameter file and on commandline, commandline parameter will override the one specified in application parameter file.

    .PARAMETER OverwriteBehavior
    Overwrite Behavior if an application exists in the cluster with the same name. Available Options are Never, Always, SameAppTypeAndVersion. 
    Never will not remove the existing application. This is the default behavior.
    Always will remove the existing application even if its Application type and Version is different from the application being created. 
    SameAppTypeAndVersion will remove the existing application only if its Application type and Version is same as the application being created.

    .PARAMETER SkipPackageValidation
    Switch signaling whether the package should be validated or not before deployment.

    .EXAMPLE
    Publish-NewServiceFabricApplication -ApplicationPackagePath 'pkg\Debug' -ApplicationParameterFilePath 'Local.xml'

    Registers & Creates an application with AppParameter file containing name of application and values for parameters that are defined in the application manifest.

    Publish-NewServiceFabricApplication -ApplicationPackagePath 'pkg\Debug' -ApplicationName 'fabric:/Application1'

    Registers & Creates an application with the specified application name.

    #>

    [CmdletBinding(DefaultParameterSetName="ApplicationName")]  
    Param
    (
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationName")]
        [String]$ApplicationPackagePath,
    
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationParameterFilePath")]
        [String]$ApplicationParameterFilePath,    

        [Parameter(Mandatory=$true,ParameterSetName="ApplicationName")]
        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [String]$ApplicationName,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [ValidateSet('Register','Create','RegisterAndCreate')]
        [String]$Action = 'RegisterAndCreate',

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Hashtable]$ApplicationParameter,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [ValidateSet('Never','Always','SameAppTypeAndVersion')]
        [String]$OverwriteBehavior = 'Never',

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Switch]$SkipPackageValidation
    )


    if (!(Test-Path $ApplicationPackagePath))
    {
        $errMsg = "$ApplicationPackagePath is not found."
        throw $errMsg
    }

    # Check if the ApplicationPackagePath points to a compressed package.
    if (Test-Path $ApplicationPackagePath -PathType Leaf)
    {
        if((Get-Item $ApplicationPackagePath).Extension -eq ".sfpkg")
        {
            $AppPkgPathToUse=[io.path]::combine($env:Temp, (Get-Item $ApplicationPackagePath).BaseName)
            Expand-ToFolder $ApplicationPackagePath $AppPkgPathToUse
        }
        else
        {
            $errMsg = "$ApplicationPackagePath is not a valid Service Fabric application package"
            throw $errMsg
        }
    }
    else
    {
        $AppPkgPathToUse = $ApplicationPackagePath
    }

    if ($PSBoundParameters.ContainsKey('ApplicationParameterFilePath') -and !(Test-Path $ApplicationParameterFilePath -PathType Leaf))
    {
        $errMsg = "$ApplicationParameterFilePath is not found."
        throw $errMsg
    }

    if(!$SkipPackageValidation)
    {
        $packageValidationSuccess = (Test-ServiceFabricApplicationPackage $AppPkgPathToUse)
        if (!$packageValidationSuccess)
        {
           $errMsg = "Validation failed for package: " +  $ApplicationPackagePath
           throw $errMsg
        }
    }

    $ApplicationManifestPath = "$AppPkgPathToUse\ApplicationManifest.xml"

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to Verify connection to Service Fabric cluster."
        throw
    }    

    # If ApplicationName is not specified on command line get application name from Application Parameter file.
    if(!$ApplicationName)
    {
       $ApplicationName = Get-ApplicationNameFromApplicationParameterFile $ApplicationParameterFilePath
    }

    $names = Get-NamesFromApplicationManifest -ApplicationManifestPath $ApplicationManifestPath
    if (!$names)
    {
        Write-Warning "Unable to read Application Type and Version from application manifest file."
        return
    }

    if($Action.Equals("Register") -or $Action.Equals("RegisterAndCreate"))
    {
        # Apply OverwriteBehavior if an applciation with same name already exists.
        $app = Get-ServiceFabricApplication -ApplicationName $ApplicationName
        if ($app)
        {
            $removeApp = $false
            if($OverwriteBehavior.Equals("Never"))
            {
                $errMsg = "An application with name '$ApplicationName' already exists, its Type is '$($app.ApplicationTypeName)' and Version is '$($app.ApplicationTypeVersion)'.
                You must first remove the existing application before a new application can be deployed or provide a new name for the application."
                throw $errMsg
            }

            if($OverwriteBehavior.Equals("SameAppTypeAndVersion")) 
            {
                if($app.ApplicationTypeVersion -eq $names.ApplicationTypeVersion -and $app.ApplicationTypeName -eq $names.ApplicationTypeName)
                {
                    $removeApp = $true
                }
                else
                {
                    $errMsg = "An application with name '$ApplicationName' already exists, its Type is '$($app.ApplicationTypeName)' and Version is '$($app.ApplicationTypeVersion)'.
                    You must first remove the existing application before a new application can be deployed or provide a new name for the application."
                    throw $errMsg
                }             
            }

            if($OverwriteBehavior.Equals("Always"))
            {
                $removeApp = $true
            }            

            if($removeApp)
            {
				Write-Host "An application with name '$ApplicationName' already exists in the cluster with Application Type '$($app.ApplicationTypeName)' and Version '$($app.ApplicationTypeVersion)'. Removing it."

                try
				{
				    $app | Remove-ServiceFabricApplication -Force
			    }
				catch [System.TimeoutException]
				{
					# Catch operation timeout and continue with force remove replica.
				}

                foreach ($node in Get-ServiceFabricNode)
                {
                    [void](Get-ServiceFabricDeployedReplica -NodeName $node.NodeName -ApplicationName $ApplicationName | Remove-ServiceFabricReplica -NodeName $node.NodeName -ForceRemove)
                }

                if($OverwriteBehavior.Equals("Always"))
                {                    
                    # Unregsiter AppType and Version if there are no other applciations for the Type and Version. 
                    # It will unregister the existing application's type and version even if its different from the application being created,
                    if((Get-ServiceFabricApplication | Where-Object {$_.ApplicationTypeVersion -eq $($app.ApplicationTypeVersion) -and $_.ApplicationTypeName -eq $($app.ApplicationTypeName)}).Count -eq 0)
                    {
                        Unregister-ServiceFabricApplicationType -ApplicationTypeName $($app.ApplicationTypeName) -ApplicationTypeVersion $($app.ApplicationTypeVersion) -Force
                    }
                }
            }
        }        

        $reg = Get-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName | Where-Object  { $_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion }
        if ($reg)
        {
            Write-Host 'Application Type '$names.ApplicationTypeName' and Version '$names.ApplicationTypeVersion' was already registered with Cluster, unregistering it...'
            $reg | Unregister-ServiceFabricApplicationType -Force
            if(!$?)
            {
                throw "Unregistering of existing Application Type was unsuccessful."
            }
        }

        Write-Host 'Copying application to image store...'
        # Get image store connection string
        $clusterManifestText = Get-ServiceFabricClusterManifest
        $imageStoreConnectionString = Get-ImageStoreConnectionStringFromClusterManifest ([xml] $clusterManifestText)

        $applicationPackagePathInImageStore = $names.ApplicationTypeName
        Copy-ServiceFabricApplicationPackage -ApplicationPackagePath $AppPkgPathToUse -ImageStoreConnectionString $imageStoreConnectionString -ApplicationPackagePathInImageStore $applicationPackagePathInImageStore -TimeoutSec 180
        if(!$?)
        {
            throw "Copying of application package to image store failed. Cannot continue with registering the application."
        }

        Write-Host 'Registering application type...'
        Register-ServiceFabricApplicationType -ApplicationPathInImageStore $applicationPackagePathInImageStore -TimeoutSec 180
        if(!$?)
        {
            throw "Registration of application type failed."
        }

        Write-Host 'Removing application package from image store...'
        Remove-ServiceFabricApplicationPackage -ApplicationPackagePathInImageStore $applicationPackagePathInImageStore -ImageStoreConnectionString $imageStoreConnectionString
    }

    if($Action.Equals("Create") -or $Action.Equals("RegisterAndCreate"))
    {
        Write-Host 'Creating application...'

        # If application parameters file is specified read values from and merge it with parameters passed on Commandline
        if ($PSBoundParameters.ContainsKey('ApplicationParameterFilePath'))
        {
           $appParamsFromFile = Get-ApplicationParametersFromApplicationParameterFile $ApplicationParameterFilePath        
           if(!$ApplicationParameter)
            {
                $ApplicationParameter = $appParamsFromFile
            }
            else
            {
                $ApplicationParameter = Merge-Hashtables -HashTableOld $appParamsFromFile -HashTableNew $ApplicationParameter
            }    
        }
    
		Write-Host $ApplicationName;
		Write-Host $names.ApplicationTypeName;
		Write-Host $names.ApplicationTypeVersion;
		Write-Host $ApplicationParameter;
        New-ServiceFabricApplication -ApplicationName $ApplicationName -ApplicationTypeName $names.ApplicationTypeName -ApplicationTypeVersion $names.ApplicationTypeVersion -ApplicationParameter $ApplicationParameter
        if(!$?)
        {
            throw "Creation of application failed."
        }

        Write-Host 'Create application succeeded.'
    }
}



function Get-ServiceFabricApplicationStatus
    {
    <#
    .SYNOPSIS 
    Outputs messages indicating the readiness of a Service Fabric application.

    .DESCRIPTION
    This script outputs messages indicating the readiness of a Service Fabric application

    .PARAMETER ApplicationName
    Name of the Service Fabric application.

    .EXAMPLE
    Get-FabricApplicationStatus.ps1 -ApplicationName 'fabric:/SampleApp'

    Get the status of a deployed application.
    #>

    Param
    (    
        [String]
        $ApplicationName
    )

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to Verify connection to Service Fabric cluster."
        throw
    }

    $started = $false
    $ready = $false
    $retryCount = 20
    do
    {
        try
        {
            $app = Get-ServiceFabricApplication -ApplicationName $ApplicationName
            if ($app)
            {   
                if (!$started)
                {
                    $started = $true
                    Write-Host "The application has started."
                }

                $ready = $true
                Write-Host "Service Status:"
                $services = $app | Get-ServiceFabricService
                foreach($s in $services)
                {
                    $remaining = $s | Get-ServiceFabricPartition | Where-Object {$_.PartitionStatus -ne "Ready"} | Measure
                    if($remaining.Count -gt 0)
                    {
                        $ready = $false
                        Write-Host "$($s.ServiceName) is not ready, $($remaining.Count) partitions remaining."
                    }
                    else
                    {
                        Write-Host "$($s.ServiceName) is ready."
                    }
                }
            }
            else
            {
                Write-Host "Waiting for the application to start."
            }
            Write-Host ""
        }
        finally
        {
            if(!$ready)
            {
                Start-Sleep -Seconds 5
            }
            $retryCount--
        }
    } while (!$ready -and $retryCount -gt 0)

    if(!$ready)
    {
        Write-Host "Something is taking too long, the application is still not ready."
    }
    else
    {
        Write-Host "The application is ready."
    }
}


function New-ServiceFabricApplicationPackage
{
    <#
    .SYNOPSIS 
    Creates a .sfpkg file from an existing Service Fabric application package directory.

    .DESCRIPTION
    Creates a .sfpkg file from an existing Service Fabric application package directory. A valid .sfpkg can the be published to Service Fabric Cluster.
    
    .PARAMETER ApplicationPackagePath
    Path to the folder containing the Service Fabric application package.
    
    .PARAMETER SFpkgName
    Name of the .sfpkg file to be created.
    
    .PARAMETER SFpkgOutputPath
    Path where you want the .sfpkg file to be placed.  
    
    .PARAMETER $Force
    Replace file if it already exists. 

    .EXAMPLE
    Create-ServiceFabricApplicationPackage -ApplicationPackagePath 'pkg\Debug' -SFpkgName 'MyAppV1'

    Creates a MyAppV1.sfpkg file.  

    Create-ServiceFabricApplicationPackage -ApplicationPackagePath 'pkg\Debug' -SFpkgName 'MyAppV1' -SFpkgOutputPath 'C:\ServiceFabricApplicationPackages'

    Creates a MyAppV1.sfpkg file, and places it in the output path 'C:\ServiceFabricApplicationPackages'

    #>
    
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)]
        [String]$ApplicationPackagePath,
        
        [Parameter(Mandatory=$true)]
        [String]$SFpkgName,
        
        [Parameter()]
        [String]$SFpkgOutputPath = (Get-Location),

        [Parameter()]
        [switch] $Force
        
    )

    
    if (!(Test-Path $ApplicationPackagePath))
    {
        $errMsg = "ApplicationPackagePath is not found."
        throw $errMsg
    }
    if (Test-Path $ApplicationPackagePath -PathType Leaf)
    {
        $errMsg = "$ApplicationPackagePath must be a path to a directory."
        throw $errMsg
    }
    
    $packageValidationSuccess = (Test-ServiceFabricApplicationPackage $ApplicationPackagePath)
    if (!$packageValidationSuccess)
    {
       $errMsg = "Validation failed for package: " +  $ApplicationPackagePath
       throw $errMsg
    }
    
    $invalidFileNamepattern = "[{0}]" -f ([Regex]::Escape( [System.IO.Path]::GetInvalidFileNameChars() -join '' ))
    if($SFpkgName -match $invalidFileNamepattern)
    {
       $errMsg = "SFpkgName has some invalid characters: " +  $SFpkgName
       throw $errMsg
    }
    if (!(Test-Path $SFpkgOutputPath))
    {
        $errMsg = "SFpkgOutputPath is not found."
        throw $errMsg
    }
    if (Test-Path $SFpkgOutputPath -PathType Leaf)
    {
        $errMsg = "$SFpkgOutputPath must be a path to a directory."
        throw $errMsg
    }

    $SFpkgPath = (Convert-Path $SFpkgOutputPath) + "\" + $SFpkgName + ".sfpkg"

    if (Test-Path $SFpkgPath -PathType Leaf)
    {
      $SFpkgPathFormatted = Convert-Path $SFpkgPath
      if(-Not $Force)
      {
          [ValidateSet('Y','N')]$ReplaceFile = Read-Host $SFpkgPathFormatted " already exists. Do you want to replace it? (Y/N)"
          if($ReplaceFile.ToLower().Contains("n"))
          {
            return
          }
      }
      Remove-Item $SFpkgPathFormatted
    }

    Compress-ToFile $ApplicationPackagePath $SFpkgPath
}



function Publish-UpgradedServiceFabricApplication
{
    <#
    .SYNOPSIS 
    Publishes and starts an upgrade for an existing Service Fabric application in Service Fabric cluster.

    .DESCRIPTION
    This script registers & starts an upgrade for Service Fabric application.

    .NOTES
    Connection to service fabric cluster should be established by using 'Connect-ServiceFabricCluster' before invoking this cmdlet.

    .PARAMETER ApplicationPackagePath
    Path to the folder containing the Service Fabric application package OR path to the zipped service fabric applciation package.

    .PARAMETER ApplicationParameterFilePath
    Path to the application parameter file which contains Application Name and application parameters to be used for the application.    

    .PARAMETER ApplicationName
    Name of Service Fabric application to be created. If value for this parameter is provided alongwith ApplicationParameterFilePath it will override the Application name specified in ApplicationParameter file.

    .PARAMETER Action
    Action which this script performs. Available Options are Register, Upgrade, RegisterAndUpgrade. Default Action is RegisterAndUpgrade.

    .PARAMETER ApplicationParameter
    Hashtable of the Service Fabric application parameters to be used for the application. If value for this parameter is provided, it will be merged with application parameters
    specified in ApplicationParameter file. In case a parameter is found ina pplication parameter file and on commandline, commandline parameter will override the one specified in application parameter file.

    .PARAMETER UpgradeParameters
    Hashtable of the upgrade parameters to be used for this upgrade. If Upgrade parameters are not specified then script will perform an UnmonitoredAuto upgrade.

    .PARAMETER UnregisterUnusedVersions
    Switch signalling if older vesions of the application need to be unregistered after upgrade.

    .PARAMETER SkipPackageValidation
    Switch signaling whether the package should be validated or not before deployment.

    .EXAMPLE
    Publish-UpgradeServiceFabricApplication -ApplicationPackagePath 'pkg\Debug' -ApplicationParameterFilePath 'AppParameters.Local.xml'

    Registers & Upgrades an application with AppParameter file containing name of application and values for parameters that are defined in the application manifest.

    Publish-UpgradesServiceFabricApplication -ApplicationPackagePath 'pkg\Debug' -ApplicationName 'fabric:/Application1'

    Registers & Upgrades an application with the specified applciation name.

    #>

    [CmdletBinding(DefaultParameterSetName="ApplicationName")]  
    Param
    (
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(Mandatory=$true,ParameterSetName="ApplicationName")]
        [String]$ApplicationPackagePath,

        [Parameter(Mandatory=$true,ParameterSetName="ApplicationParameterFilePath")]
        [String]$ApplicationParameterFilePath,

        [Parameter(Mandatory=$true,ParameterSetName="ApplicationName")]
        [String]$ApplicationName,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [ValidateSet('Register','Upgrade','RegisterAndUpgrade')]
        [String]$Action = 'RegisterAndUpgrade',

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Hashtable]$ApplicationParameter,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Hashtable]$UpgradeParameters = @{UnmonitoredAuto = $true},

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Switch]$UnregisterUnusedVersions,

        [Parameter(ParameterSetName="ApplicationParameterFilePath")]
        [Parameter(ParameterSetName="ApplicationName")]
        [Switch]$SkipPackageValidation
    )


    if (!(Test-Path $ApplicationPackagePath))
    {
        $errMsg = "$ApplicationPackagePath is not found."
        throw $errMsg
    }

    if (Test-Path $ApplicationPackagePath -PathType Leaf)
    {
        if((Get-Item $ApplicationPackagePath).Extension -eq ".sfpkg")
        {
            $AppPkgPathToUse=[io.path]::combine($env:Temp, (Get-Item $ApplicationPackagePath).BaseName)
            Expand-ToFolder $ApplicationPackagePath $AppPkgPathToUse
        }
        else
        {
            $errMsg = "$ApplicationPackagePath is not a valid Service Fabric application package"
            throw $errMsg
        }
    }
    else
    {
        $AppPkgPathToUse = $ApplicationPackagePath
    }

    if ($PSBoundParameters.ContainsKey('ApplicationParameterFilePath') -and !(Test-Path $ApplicationParameterFilePath -PathType Leaf))
    {
        $errMsg = "$ApplicationParameterFilePath is not found."
        throw $errMsg
    }

	# Get image store connection string
    $clusterManifestText = Get-ServiceFabricClusterManifest
	$imageStoreConnectionString = Get-ImageStoreConnectionStringFromClusterManifest ([xml] $clusterManifestText)

    if(!$SkipPackageValidation)
    {
        $packageValidationSuccess = (Test-ServiceFabricApplicationPackage $AppPkgPathToUse -ImageStoreConnectionString $imageStoreConnectionString)
        if (!$packageValidationSuccess)
        {
           $errMsg = "Validation failed for package: " +  $ApplicationPackagePath
           throw $errMsg
        }
    }

    $ApplicationManifestPath = "$AppPkgPathToUse\ApplicationManifest.xml"    

    try
    {
        [void](Test-ServiceFabricClusterConnection)
    }
    catch
    {
        Write-Warning "Unable to verify connection to Service Fabric cluster."
        throw
    }

    # If ApplicationName is not specified on command line get application name from Application parameter file.
    if(!$ApplicationName)
    {
       $ApplicationName = Get-ApplicationNameFromApplicationParameterFile $ApplicationParameterFilePath
    }

    $names = Get-NamesFromApplicationManifest -ApplicationManifestPath $ApplicationManifestPath
    if (!$names)
    {
        return
    }

    if ($Action.Equals('RegisterAndUpgrade') -or $Action.Equals('Register'))
    {    
        ## Check existence of the application
        $oldApplication = Get-ServiceFabricApplication -ApplicationName $ApplicationName
        
        if (!$oldApplication)
        {
            $errMsg = "Application '$ApplicationName' doesn't exist in cluster."
            throw $errMsg
        }
        else
        {
            if($oldApplication.ApplicationTypeName -ne $names.ApplicationTypeName)
            {   
                $errMsg =  "Application type of application '$ApplicationName' doesn't match with the Application Type in application manifest specified in the new application package.
                Please ensure that the application being upgraded is of the same Applciation Type."
                throw $errMsg
            }
        }                
    
        ## Check upgrade status
        $upgradeStatus = Get-ServiceFabricApplicationUpgrade -ApplicationName $ApplicationName
        if ($upgradeStatus.UpgradeState -ne "RollingBackCompleted" -and $upgradeStatus.UpgradeState -ne "RollingForwardCompleted")
        {
            $errMsg = "An upgrade for the application '$names.ApplicationTypeName' is already in progress."
            throw $errMsg
        }

        $reg = Get-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName | Where-Object  { $_.ApplicationTypeVersion -eq $names.ApplicationTypeVersion }
        if ($reg)
        {
            Write-Host 'Application Type '$names.ApplicationTypeName' and Version '$names.ApplicationTypeVersion' was already registered with Cluster, unregistering it...'
            $reg | Unregister-ServiceFabricApplicationType -Force
        }
    
        $applicationPackagePathInImageStore = $names.ApplicationTypeName
        Write-Host "Copying application package to image store..."
        Copy-ServiceFabricApplicationPackage -ApplicationPackagePath $AppPkgPathToUse -ImageStoreConnectionString $imageStoreConnectionString -ApplicationPackagePathInImageStore $applicationPackagePathInImageStore -TimeoutSec 180
        if(!$?)
        {
            throw "Copying of application package to image store failed. Cannot continue with registering the application."
        }
    
        Write-Host "Registering application type..."
        Register-ServiceFabricApplicationType -ApplicationPathInImageStore $applicationPackagePathInImageStore -TimeoutSec 180
        if(!$?)
        {
            throw "Registration of application type failed."
        }
     }
    
    if ($Action.Equals('Upgrade') -or $Action.Equals('RegisterAndUpgrade'))
    {
        try
        {
            $UpgradeParameters["ApplicationName"] = $ApplicationName
            $UpgradeParameters["ApplicationTypeVersion"] = $names.ApplicationTypeVersion
        
             # If application parameters file is specified read values from and merge it with parameters passed on Commandline
            if ($PSBoundParameters.ContainsKey('ApplicationParameterFilePath'))
            {
                $appParamsFromFile = Get-ApplicationParametersFromApplicationParameterFile $ApplicationParameterFilePath        
                if(!$ApplicationParameter)
                {
                    $ApplicationParameter = $appParamsFromFile
                }
                else
                {
                    $ApplicationParameter = Merge-Hashtables -HashTableOld $appParamsFromFile -HashTableNew $ApplicationParameter
                }    
            }
     
            $UpgradeParameters["ApplicationParameter"] = $ApplicationParameter

            $serviceTypeHealthPolicyMap = $upgradeParameters["ServiceTypeHealthPolicyMap"]
            if ($serviceTypeHealthPolicyMap -and $serviceTypeHealthPolicyMap -is [string])
            {
                $upgradeParameters["ServiceTypeHealthPolicyMap"] = Invoke-Expression $serviceTypeHealthPolicyMap
            }
        
            Write-Host "Start upgrading application..." 
            Start-ServiceFabricApplicationUpgrade @UpgradeParameters
        }
        catch
        {
            Write-Host "Unregister application type '$names.ApplicationTypeName' and version '$names.ApplicationTypeVersion' ..."
            Unregister-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName -ApplicationTypeVersion $names.ApplicationTypeVersion -Force
            throw
        }

        if (!$UpgradeParameters["Monitored"] -and !$UpgradeParameters["UnmonitoredAuto"])
        {
            return
        }
    
        do
        {
            Write-Host "Waiting for upgrade..."
            Start-Sleep -Seconds 3
            $upgradeStatus = Get-ServiceFabricApplicationUpgrade -ApplicationName $ApplicationName
        } while ($upgradeStatus.UpgradeState -ne "RollingBackCompleted" -and $upgradeStatus.UpgradeState -ne "RollingForwardCompleted")
    
        if($UnregisterUnusedVersions)
        {
            Write-Host 'Unregistering other unused versions for the application type...'
            foreach($registeredAppTypes in Get-ServiceFabricApplicationType -ApplicationTypeName $names.ApplicationTypeName | Where-Object  { $_.ApplicationTypeVersion -ne $names.ApplicationTypeVersion })
            {
                try
                {
                    $registeredAppTypes | Unregister-ServiceFabricApplicationType -Force
                }
                catch [System.Fabric.FabricException]
                {
                    # AppType and Version in use.
                }
            }
        }

        if($upgradeStatus.UpgradeState -eq "RollingForwardCompleted")
        {
            Write-Host "Upgrade completed successfully."
        }
        elseif($upgradeStatus.UpgradeState -eq "RollingBackCompleted")
        {
            Write-Host "Upgrade was Rolled back."
        }
    }
}



function Remove-ServiceFabricApplicationType
{
<#
.SYNOPSIS 
Removes all the applciations for the specified service fabric application type & version and unregisters thea applicaiton type and version.

.DESCRIPTION
Removes all the applciations for the specified service fabric application type & version and unregisters thea applicaiton type and version.

.NOTES
WARNING: This script file is invoked by Visual Studio.  Its parameters must not be altered.

.PARAMETER ApplicationTypeName
The name of the application type to remove.

.PARAMETER ApplicationTypeVersion
The version of the application type to remove.

.EXAMPLE
Remove-ApplicationType.ps1 -ApplicationTypeName 'MyApplicationType' -ApplicationTypeVersion '1.0.0.0'
#>

Param
(
    [Parameter(Mandatory=$true)]
    [String]
    $ApplicationTypeName,

    [Parameter(Mandatory=$true)]
    [String]
    $ApplicationTypeVersion
)


Write-Host "Removing application type..."

try
{
    [void](Test-ServiceFabricClusterConnection)
}
catch
{
    Write-Warning "Unable to Verify connection to Service Fabric cluster."
    throw
}

$nodes = Get-ServiceFabricNode
foreach ($app in Get-ServiceFabricApplication)
{
    if ($app.ApplicationTypeName -eq $ApplicationTypeName -and $app.ApplicationTypeVersion -eq $ApplicationTypeVersion)
    {
		try
		{
            $app | Remove-ServiceFabricApplication -Force
		}
	    catch [System.TimeoutException]
        {
	        # Catch operation timeout and continue with force remove replica.
        }

        foreach ($node in $nodes)
        {
            [void](Get-ServiceFabricDeployedReplica -NodeName $node.NodeName -ApplicationName $app.ApplicationName | Remove-ServiceFabricReplica -NodeName $node.NodeName -ForceRemove)
        }
    }
}

$reg = Get-ServiceFabricApplicationType -ApplicationTypeName $ApplicationTypeName | Where-Object { $_.ApplicationTypeVersion -eq $ApplicationTypeVersion }
if ($reg)
{
    $reg | Unregister-ServiceFabricApplicationType -ApplicationTypeVersion $ApplicationTypeVersion -Force
}

Write-Host "Finished removing the application type"

}




function Unpublish-ServiceFabricApplication
{

<#
.SYNOPSIS 
Removes the specified service fabric application

.DESCRIPTION
This script removes the application.

.NOTES
This will forcefully Removes all the replicsa for the specified service fabric application.

.PARAMETER ApplicationName
The name of the application type to remove.

.EXAMPLE
Remove-Application.ps1 -ApplicationName 'fabric:/MyApplication'
#>

Param
(
    [Parameter(Mandatory=$true)]
    [String]
    $ApplicationName
)


Write-Host "Removing application..."

try
{
    [void](Test-ServiceFabricClusterConnection)
}
catch
{
    Write-Warning "Unable to Verify connection to Service Fabric cluster."
    throw
}

$app = Get-ServiceFabricApplication -ApplicationName $ApplicationName
if ($app)
{
	try
	{
		$app | Remove-ServiceFabricApplication -Force
	}
	catch [System.TimeoutException]
    {
	    # Catch operation timeout and continue with force remove replica.
    }
}

foreach ($node in Get-ServiceFabricNode)
{
    [void](Get-ServiceFabricDeployedReplica -NodeName $node.NodeName -ApplicationName $ApplicationName | Remove-ServiceFabricReplica -NodeName $node.NodeName -ForceRemove)
}

}


function Copy-ToTemp
{
    <#
    .SYNOPSIS 
    Copies files to a temp folder.

    .PARAMETER From
    Source location from which to copy files.

    .PARAMETER Name
    Folder name within temp location to store the files.
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $From,
        
        [String]
        $Name
    )

    if (!(Test-Path $From))
    {
        return $null
    }

    $To = $env:Temp + '\' + $Name
    
    if (Test-Path $To)
    {
        Remove-Item -Path $To -Recurse -ErrorAction Stop | Out-Null
    }

    New-Item $To -ItemType directory | Out-Null

    robocopy "$From" "$To" /E /MT | Out-Null

    # robocopy has non-standard exit values that are documented here: https://support.microsoft.com/en-us/kb/954404
    # Exit codes 0-8 are considered success, while all other exit codes indicate at least one failure.
    # Some build systems treat all non-0 return values as failures, so we massage the exit code into
    # something that they can understand.
    if (($LASTEXITCODE -ge 0) -and ($LASTEXITCODE -le 8))
    {
        # Simply setting $LASTEXITCODE in this script will not override the script's exit code.
        # We need to start a new process and let it exit.
        PowerShell -NoProfile -Command "exit 0"
    }

    return $env:Temp + '\' + $Name
}

function Expand-ToFolder
{
    <#
    .SYNOPSIS 
    Unzips the zip file to the specified folder.

    .PARAMETER From
    Source location to unzip

    .PARAMETER Name
    Folder name to expand the files to.
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $File,
        
        [String]
        $Destination
    )

    if (!(Test-Path $File))
    {
        return
    }    
    
    if (Test-Path $Destination)
    {
        Remove-Item -Path $Destination -Recurse -ErrorAction Stop | Out-Null
    }

    New-Item $Destination -ItemType directory | Out-Null


    Write-Verbose -Message "Attempting to Unzip $File to location $Destination" 
    try 
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null 
        [System.IO.Compression.ZipFile]::ExtractToDirectory("$File", "$Destination") 
    } 
    catch 
    { 
        Write-Error -Message "Unexpected Error. Error details: $_.Exception.Message" 
    } 
}

function Compress-ToFile
{
   <#
    .SYNOPSIS 
    Compress the Source Directory to a zip file.

    .PARAMETER SourceDir
    Path of the directory to zip

    .PARAMETER FileName
    Name of the zip file to generate. 
    #>
    
   [CmdletBinding()]
    Param
    (
        [String]
        $SourceDir,
        
        [String]
        $FileName
    )
    
    if (!(Test-Path $SourceDir))
    {
        return
    }  
    
    try 
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null 
        $compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
        [System.IO.Compression.ZipFile]::CreateFromDirectory($SourceDir,$FileName, $compressionLevel, $false)
    }
    catch 
    { 
        Write-Error -Message "Unexpected Error. Error details: $_.Exception.Message" 
    } 
}

function Get-NamesFromApplicationManifest
{
    <#
    .SYNOPSIS 
    Returns an object containing common information from the application manifest.

    .PARAMETER ApplicationManifestPath
    Path to the application manifest file.    
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $ApplicationManifestPath
    )

    if (!(Test-Path $ApplicationManifestPath))
    {
        throw "$ApplicationManifestPath is not found."
    }

    
    $appXml = [xml] (Get-Content $ApplicationManifestPath)
    if (!$appXml)
    {
        return
    }

    $appMan = $appXml.ApplicationManifest
    $FabricNamespace = 'fabric:'
    $appTypeSuffix = 'Type'

    $h = @{
        FabricNamespace = $FabricNamespace;
        ApplicationTypeName = $appMan.ApplicationTypeName;
        ApplicationTypeVersion = $appMan.ApplicationTypeVersion;
    }   

    Write-Output (New-Object psobject -Property $h)
}

function Get-ImageStoreConnectionStringFromClusterManifest
{
    <#
    .SYNOPSIS 
    Returns the value of the image store connection string from the cluster manifest.

    .PARAMETER ClusterManifest
    Contents of cluster manifest file.
    #>

    [CmdletBinding()]
    Param
    (
        [xml]
        $ClusterManifest
    )

    $managementSection = $ClusterManifest.ClusterManifest.FabricSettings.Section | ? { $_.Name -eq "Management" }
    return $managementSection.ChildNodes | ? { $_.Name -eq "ImageStoreConnectionString" } | Select-Object -Expand Value
}


function Get-ApplicationNameFromApplicationParameterFile
{
    <#
    .SYNOPSIS 
    Returns Application Name from ApplicationParameter xml file.

    .PARAMETER ApplicationParameterFilePath
    Path to the application parameter file
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $ApplicationParameterFilePath
    )
    
    if (!(Test-Path $ApplicationParameterFilePath))
    {
        $errMsg = "$ApplicationParameterFilePath is not found."
        throw $errMsg
    }

    return ([xml] (Get-Content $ApplicationParameterFilePath)).Application.Name
}


function Get-ApplicationParametersFromApplicationParameterFile
{
    <#
    .SYNOPSIS 
    Reads ApplicationParameter xml file and returns HashTable containing ApplicationParameters.

    .PARAMETER ApplicationParameterFilePath
    Path to the application parameter file
    #>

    [CmdletBinding()]
    Param
    (
        [String]
        $ApplicationParameterFilePath
    )
    
    if (!(Test-Path $ApplicationParameterFilePath))
    {
        throw "$ApplicationParameterFilePath is not found."
    }
    
    $ParametersXml = ([xml] (Get-Content $ApplicationParameterFilePath)).Application.Parameters

    $hash = @{}
    $ParametersXml.ChildNodes | foreach {
       if ($_.LocalName -eq 'Parameter') {
       $hash[$_.Name] = $_.Value
       }
    }

    return $hash
}

function Merge-HashTables
{
    <#
    .SYNOPSIS 
    Merges 2 hashtables. Key, value pairs form HashTableNew are preserved if any duplciates are found between HashTableOld & HashTableNew.

    .PARAMETER HashTableOld
    First Hashtable.
    
    .PARAMETER HashTableNew
    Second Hashtable 
    #>

    [CmdletBinding()]
    Param
    (
        [HashTable]
        $HashTableOld,
        
        [HashTable]
        $HashTableNew
    )
    
    $keys = $HashTableOld.getenumerator() | foreach-object {$_.key}
    $keys | foreach-object {
        $key = $_
        if ($HashTableNew.containskey($key))
        {
            $HashTableOld.remove($key)
        }
    }
    $HashTableNew = $HashTableOld + $HashTableNew
    return $HashTableNew
}



function Read-XmlElementAsHashtable
{
    Param (
        [System.Xml.XmlElement]
        $Element
    )

    $hashtable = @{}
    if ($Element.Attributes)
    {
        $Element.Attributes | 
            ForEach-Object {
                $boolVal = $null
                if ([bool]::TryParse($_.Value, [ref]$boolVal)) {
                    $hashtable[$_.Name] = $boolVal
                }
                else {
                    $hashtable[$_.Name] = $_.Value
                }
            }
    }

    return $hashtable
}

function Read-PublishProfile
{
    Param (
        [ValidateScript({Test-Path $_ -PathType Leaf})]
        [String]
        $PublishProfileFile
    )

    $publishProfileXml = [Xml] (Get-Content $PublishProfileFile)
    $publishProfile = @{}

    $publishProfile.ClusterConnectionParameters = Read-XmlElementAsHashtable $publishProfileXml.PublishProfile.Item("ClusterConnectionParameters")
    $publishProfile.UpgradeDeployment = Read-XmlElementAsHashtable $publishProfileXml.PublishProfile.Item("UpgradeDeployment")

    if ($publishProfileXml.PublishProfile.Item("UpgradeDeployment"))
    {
        $publishProfile.UpgradeDeployment.Parameters = Read-XmlElementAsHashtable $publishProfileXml.PublishProfile.Item("UpgradeDeployment").Item("Parameters")
        if ($publishProfile.UpgradeDeployment["Mode"])
        {
            $publishProfile.UpgradeDeployment.Parameters[$publishProfile.UpgradeDeployment["Mode"]] = $true
        }
    }

    $publishProfileFolder = (Split-Path $PublishProfileFile)
    $publishProfile.ApplicationParameterFile = [System.IO.Path]::Combine($PublishProfileFolder, $publishProfileXml.PublishProfile.ApplicationParameterFile.Path)

    return $publishProfile
}

$LocalFolder = (Split-Path $MyInvocation.MyCommand.Path)

if (!$PublishProfileFile)
{
    $PublishProfileFile = "$LocalFolder\..\PublishProfiles\Local.xml"
}

if (!$ApplicationPackagePath)
{
    $ApplicationPackagePath = "$LocalFolder\..\pkg\Release"
}

$ApplicationPackagePath = Resolve-Path $ApplicationPackagePath

$publishProfile = Read-PublishProfile $PublishProfileFile

if (-not $UseExistingClusterConnection)
{
    $ClusterConnectionParameters = $publishProfile.ClusterConnectionParameters
    if ($SecurityToken)
    {
        $ClusterConnectionParameters["SecurityToken"] = $SecurityToken
    }

    try
    {
        [void](Connect-ServiceFabricCluster @ClusterConnectionParameters)
        $global:clusterConnection = $clusterConnection
    }
    catch [System.Fabric.FabricObjectClosedException]
    {
        Write-Warning "Service Fabric cluster may not be connected."
        throw
    }
}

#$RegKey = "HKLM:\SOFTWARE\Microsoft\Service Fabric SDK"
#$ModuleFolderPath = (Get-ItemProperty -Path $RegKey -Name FabricSDKPSModulePath).FabricSDKPSModulePath
#Import-Module "$ModuleFolderPath\ServiceFabricSDK.psm1"

$IsUpgrade = ($publishProfile.UpgradeDeployment -and $publishProfile.UpgradeDeployment.Enabled -and $OverrideUpgradeBehavior -ne 'VetoUpgrade') -or $OverrideUpgradeBehavior -eq 'ForceUpgrade'

if ($IsUpgrade)
{
    $Action = "RegisterAndUpgrade"
    if ($DeployOnly)
    {
        $Action = "Register"
    }
    
    $UpgradeParameters = $publishProfile.UpgradeDeployment.Parameters

    if ($OverrideUpgradeBehavior -eq 'ForceUpgrade')
    {
        # Warning: Do not alter these upgrade parameters. It will create an inconsistency with Visual Studio's behavior.
        $UpgradeParameters = @{ UnmonitoredAuto = $true; Force = $true }
    }

    Publish-UpgradedServiceFabricApplication -ApplicationPackagePath $ApplicationPackagePath -ApplicationParameterFilePath $publishProfile.ApplicationParameterFile -Action $Action -UpgradeParameters $UpgradeParameters -ApplicationParameter $ApplicationParameter -UnregisterUnusedVersions:$UnregisterUnusedApplicationVersionsAfterUpgrade -ErrorAction Stop
}
else
{
    $Action = "RegisterAndCreate"
    if ($DeployOnly)
    {
        $Action = "Register"
    }
    
    Publish-NewServiceFabricApplication -ApplicationPackagePath $ApplicationPackagePath -ApplicationParameterFilePath $publishProfile.ApplicationParameterFile -Action $Action -ApplicationParameter $ApplicationParameter -OverwriteBehavior $OverwriteBehavior -SkipPackageValidation:$SkipPackageValidation -ErrorAction Stop
}